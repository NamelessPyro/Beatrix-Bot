#!/usr/bin/env python3
"""
Main entry point for Beatrix Discord Music Bot.
"""

import asyncio
import os
import sys
from pathlib import Path

# Add the project root to Python path
sys.path.insert(0, str(Path(__file__).parent))

from Beatrix.bot import create_bot


async def main():
    """Main entry point."""
    print("🎵 Starting Beatrix Music Bot...")
    
    try:
        # Load environment variables from .env file if it exists
        env_file = Path(__file__).parent / '.env'
        if env_file.exists():
            with open(env_file) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        os.environ[key.strip()] = value.strip()
        
        # Get Discord token
        token = os.getenv("DISCORD_TOKEN")
        if not token:
            print("❌ Error: DISCORD_TOKEN not found!")
            print("Please check your .env file or set the environment variable:")
            print("   $env:DISCORD_TOKEN='your_bot_token_here'")
            sys.exit(1)
        
        # Create and start bot
        bot, _ = await create_bot(token)
        
        print(f"🚀 Bot created successfully!")
        print(f"📁 Music directory: {bot.config.music_dir}")
        print(f"🎧 FFmpeg path: {bot.config.ffmpeg_path}")
        print("🔗 Starting bot connection...")
        
        await bot.start(token)
        
    except KeyboardInterrupt:
        print("\n⏹️ Bot stopped by user (Ctrl+C)")
    except Exception as e:
        print(f"❌ Error starting bot: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        sys.exit(1)
