# === UI COMPONENTS ===
"""
Discord UI components for the bot.
"""

import asyncio
from typing import List, Optional, Callable

import discord


class PagedEmbedView(discord.ui.View):
    """Paginated embed view for displaying lists."""
    
    def __init__(
        self,
        entries: List[str],
        title: str = "",
        color: discord.Color = discord.Color.blue(),
        chunk_size: int = 10,
        timeout: int = 180
    ):
        super().__init__(timeout=timeout)
        self.entries = entries
        self.chunk_size = chunk_size
        self.page = 0
        self.title = title
        self.color = color
        self.max_pages = (len(entries) - 1) // chunk_size + 1 if entries else 1
    
    def get_embed(self) -> discord.Embed:
        """Get the current page embed."""
        if not self.entries:
            return discord.Embed(
                title=self.title,
                description="No entries found.",
                color=self.color
            )
        
        start = self.page * self.chunk_size
        end = start + self.chunk_size
        lines = self.entries[start:end]
        
        # Number the entries
        numbered = []
        for i, line in enumerate(lines, start=start + 1):
            numbered.append(f"`{i:2d}.` {line}")
        
        embed = discord.Embed(
            title=self.title,
            description="\n".join(numbered),
            color=self.color
        )
        
        if self.max_pages > 1:
            embed.set_footer(text=f"Page {self.page + 1}/{self.max_pages} • {len(self.entries)} total entries")
        else:
            embed.set_footer(text=f"{len(self.entries)} entries")
        
        return embed
    
    async def update_view(self, interaction: discord.Interaction):
        """Update the view with current page."""
        embed = self.get_embed()
        
        # Update button states
        self.previous_button.disabled = self.page == 0
        self.next_button.disabled = self.page >= self.max_pages - 1
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="◀ Previous", style=discord.ButtonStyle.blurple, disabled=True)
    async def previous_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to previous page."""
        if self.page > 0:
            self.page -= 1
        await self.update_view(interaction)
    
    @discord.ui.button(label="Next ▶", style=discord.ButtonStyle.blurple)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to next page."""
        if self.page < self.max_pages - 1:
            self.page += 1
        await self.update_view(interaction)
    
    @discord.ui.button(label="🗑️ Close", style=discord.ButtonStyle.red)
    async def close_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Close the view."""
        self.stop()
        try:
            await interaction.response.edit_message(view=None)
            await asyncio.sleep(1)
            await interaction.delete_original_response()
        except (discord.NotFound, discord.HTTPException):
            pass
    
    async def on_timeout(self):
        """Handle view timeout."""
        self.stop()


class PlaylistSelectView(discord.ui.View):
    """View for selecting playlists with dropdown."""
    
    def __init__(
        self,
        playlists: List[str],
        placeholder: str,
        callback_func: Callable,
        timeout: int = 60
    ):
        super().__init__(timeout=timeout)
        
        if playlists:
            self.add_item(PlaylistSelect(playlists, placeholder, callback_func))
    
    async def on_timeout(self):
        """Handle view timeout."""
        self.stop()


class PlaylistSelect(discord.ui.Select):
    """Dropdown for selecting playlists."""
    
    def __init__(self, playlists: List[str], placeholder: str, callback_func: Callable):
        options = []
        for playlist in playlists[:25]:  # Discord limit
            options.append(discord.SelectOption(
                label=playlist,
                description=f"Load playlist: {playlist}",
                emoji="🎵"
            ))
        
        super().__init__(
            placeholder=placeholder,
            min_values=1,
            max_values=1,
            options=options
        )
        self.callback_func = callback_func
    
    async def callback(self, interaction: discord.Interaction):
        """Handle playlist selection."""
        await self.callback_func(interaction, self.values[0])


class ConfirmationView(discord.ui.View):
    """View for confirmation dialogs."""
    
    def __init__(self, timeout: int = 30):
        super().__init__(timeout=timeout)
        self.value: Optional[bool] = None
    
    @discord.ui.button(label="✅ Confirm", style=discord.ButtonStyle.green)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Confirm action."""
        self.value = True
        self.stop()
        await interaction.response.edit_message(view=None)
    
    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.red)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Cancel action."""
        self.value = False
        self.stop()
        await interaction.response.edit_message(view=None)
    
    async def on_timeout(self):
        """Handle timeout."""
        self.value = None
        self.stop()


class QueueControlView(discord.ui.View):
    """View for queue control buttons."""
    
    def __init__(self, bot, guild_id: int, timeout: int = 300):
        super().__init__(timeout=timeout)
        self.bot = bot
        self.guild_id = guild_id
    
    @discord.ui.button(label="⏸️ Pause", style=discord.ButtonStyle.secondary)
    async def pause_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Pause/resume playback."""
        guild = self.bot.get_guild(self.guild_id)
        if not guild:
            await interaction.response.send_message("Guild not found.", ephemeral=True)
            return
        
        vc = guild.voice_client
        if not vc:
            await interaction.response.send_message("Not connected to voice.", ephemeral=True)
            return
        
        if vc.is_playing():
            await self.bot.music_player.pause_playback(guild)
            button.label = "▶️ Resume"
            button.style = discord.ButtonStyle.green
            await interaction.response.edit_message(view=self)
        elif vc.is_paused():
            await self.bot.music_player.resume_playback(guild)
            button.label = "⏸️ Pause"
            button.style = discord.ButtonStyle.secondary
            await interaction.response.edit_message(view=self)
        else:
            await interaction.response.send_message("Nothing is playing.", ephemeral=True)
    
    @discord.ui.button(label="⏭️ Skip", style=discord.ButtonStyle.blurple)
    async def skip_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Skip current song."""
        guild = self.bot.get_guild(self.guild_id)
        if not guild:
            await interaction.response.send_message("Guild not found.", ephemeral=True)
            return
        
        if await self.bot.music_player.skip_current_song(guild):
            await interaction.response.send_message("⏭️ Skipped!", ephemeral=True)
        else:
            await interaction.response.send_message("Nothing to skip.", ephemeral=True)
    
    @discord.ui.button(label="⏹️ Stop", style=discord.ButtonStyle.red)
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Stop playback and clear queue."""
        guild = self.bot.get_guild(self.guild_id)
        if not guild:
            await interaction.response.send_message("Guild not found.", ephemeral=True)
            return
        
        if await self.bot.music_player.stop_playback(guild, clear_queue=True):
            await interaction.response.send_message("⏹️ Stopped playback and cleared queue.", ephemeral=True)
        else:
            await interaction.response.send_message("Nothing to stop.", ephemeral=True)
    
    @discord.ui.button(label="🔀 Shuffle", style=discord.ButtonStyle.secondary)
    async def shuffle_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Shuffle the queue."""
        if self.bot.queue_manager.shuffle_queue(self.guild_id):
            await interaction.response.send_message("🔀 Queue shuffled!", ephemeral=True)
        else:
            await interaction.response.send_message("Queue is empty or has only one song.", ephemeral=True)
    
    async def on_timeout(self):
        """Handle timeout."""
        self.stop()


class VolumeControlView(discord.ui.View):
    """View for volume control (if implemented)."""
    
    def __init__(self, current_volume: int = 100, timeout: int = 60):
        super().__init__(timeout=timeout)
        self.current_volume = current_volume
    
    @discord.ui.button(label="🔉 25%", style=discord.ButtonStyle.secondary)
    async def volume_25(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Set volume to 25%."""
        await interaction.response.send_message("Volume control not yet implemented.", ephemeral=True)
    
    @discord.ui.button(label="🔊 50%", style=discord.ButtonStyle.secondary) 
    async def volume_50(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Set volume to 50%."""
        await interaction.response.send_message("Volume control not yet implemented.", ephemeral=True)
    
    @discord.ui.button(label="🔊 100%", style=discord.ButtonStyle.green)
    async def volume_100(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Set volume to 100%."""
        await interaction.response.send_message("Volume control not yet implemented.", ephemeral=True)
    
    async def on_timeout(self):
        """Handle timeout."""
        self.stop()
