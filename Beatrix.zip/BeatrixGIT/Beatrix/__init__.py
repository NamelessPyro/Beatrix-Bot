# Beatrix Bot main package
#
# Copyright (c) 2025 NamelessPyro (https://youtube.com/@NamelessPyro)
# and the Beatrix Discord Music Bot project
