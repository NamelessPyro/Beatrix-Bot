# === VOICE CONNECTION MANAGER ===
"""
Manages voice connections and auto-reconnection.
"""

import asyncio
import logging
from typing import Dict, Optional

import discord

from ..config import BotConfig
from ..exceptions import VoiceConnectionError


class VoiceConnectionManager:
    """Manages voice connections and auto-reconnection."""
    
    def __init__(self, config: BotConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Track voice state
        self.last_channels: Dict[int, discord.VoiceChannel] = {}
        self.last_activity: Dict[int, float] = {}
        self.connection_attempts: Dict[int, int] = {}
        
        # Enhanced monitoring
        self.connection_status: Dict[int, dict] = {}  # guild_id -> status info
        self.alone_since: Dict[int, float] = {}  # guild_id -> timestamp when bot became alone
        self.voice_events: Dict[int, list] = {}  # guild_id -> recent voice events
    
    async def connect_to_channel(self, channel: discord.VoiceChannel) -> discord.VoiceClient:
        """Connect to voice channel with error handling."""
        guild_id = channel.guild.id
        
        try:
            # Disconnect if already connected to different channel
            if channel.guild.voice_client:
                await channel.guild.voice_client.disconnect()
            
            vc = await channel.connect()
            self.last_channels[guild_id] = channel
            self.update_activity(guild_id)
            self.connection_attempts[guild_id] = 0
            
            self.logger.info(f"Connected to {channel.name} in {channel.guild.name}")
            return vc
            
        except discord.ClientException as e:
            self.logger.error(f"Discord client error connecting to {channel.name}: {e}")
            raise VoiceConnectionError(f"Already connected to voice channel")
        except discord.OpusNotLoaded as e:
            self.logger.error(f"Opus not loaded: {e}")
            raise VoiceConnectionError("Audio codec not available")
        except Exception as e:
            self.logger.error(f"Failed to connect to voice channel {channel.name}: {e}")
            raise VoiceConnectionError(f"Could not connect: {e}")
    
    async def disconnect_from_guild(self, guild: discord.Guild) -> bool:
        """Disconnect from voice channel in guild."""
        if guild.voice_client:
            try:
                await guild.voice_client.disconnect()
                self.logger.info(f"Disconnected from voice in {guild.name}")
                return True
            except Exception as e:
                self.logger.error(f"Error disconnecting from {guild.name}: {e}")
        return False
    
    def update_activity(self, guild_id: int, alone: bool = False) -> None:
        """Update last activity time and track voice state."""
        try:
            import time
            current_time = time.time()
            self.last_activity[guild_id] = current_time
            
            # Track when bot becomes alone
            if alone:
                if guild_id not in self.alone_since:
                    self.alone_since[guild_id] = current_time
                    self.logger.info(f"Bot became alone in guild {guild_id}")
            else:
                # Bot is no longer alone
                if guild_id in self.alone_since:
                    alone_duration = current_time - self.alone_since[guild_id]
                    self.logger.info(f"Bot was alone for {alone_duration:.1f} seconds in guild {guild_id}")
                    del self.alone_since[guild_id]
            
            # Update connection status
            self.connection_status[guild_id] = {
                "last_activity": current_time,
                "is_alone": alone,
                "alone_since": self.alone_since.get(guild_id)
            }
            
        except Exception as e:
            self.logger.error(f"Error updating activity: {e}")
    
    def get_inactive_time(self, guild_id: int) -> float:
        """Get time since last activity."""
        import time
        current_time = time.time()
        last_active = self.last_activity.get(guild_id, current_time)
        return current_time - last_active
    
    def should_auto_disconnect(self, guild_id: int) -> bool:
        """Check if should auto-disconnect due to inactivity."""
        return self.get_inactive_time(guild_id) >= self.config.auto_disconnect_timeout
    
    async def attempt_reconnection(self, guild_id: int, has_queue: bool = False) -> Optional[discord.VoiceClient]:
        """Attempt to reconnect to last known channel."""
        last_channel = self.last_channels.get(guild_id)
        if not last_channel or not has_queue:
            return None
        
        # Check if there are still non-bot users in the channel
        human_members = [m for m in last_channel.members if not m.bot]
        if not human_members:
            self.logger.info(f"No users in {last_channel.name}, not reconnecting")
            return None
        
        # Check connection attempts to avoid spam
        attempts = self.connection_attempts.get(guild_id, 0)
        if attempts >= self.config.reconnect_attempts:
            self.logger.warning(f"Max reconnection attempts reached for guild {guild_id}")
            return None
        
        try:
            # Brief delay to avoid rapid reconnection
            await asyncio.sleep(2)
            
            vc = await last_channel.connect()
            self.connection_attempts[guild_id] = 0
            self.update_activity(guild_id)
            
            self.logger.info(f"Successfully reconnected to {last_channel.name}")
            return vc
            
        except Exception as e:
            self.connection_attempts[guild_id] = attempts + 1
            self.logger.error(f"Reconnection attempt {attempts + 1} failed: {e}")
            return None
    
    def get_voice_channel_info(self, guild: discord.Guild) -> Dict:
        """Get voice channel information."""
        vc = guild.voice_client
        last_channel = self.last_channels.get(guild.id)
        
        info = {
            "connected": vc is not None,
            "channel_name": vc.channel.name if vc else None,
            "channel_id": vc.channel.id if vc else None,
            "is_playing": vc.is_playing() if vc else False,
            "is_paused": vc.is_paused() if vc else False,
            "last_channel": last_channel.name if last_channel else None,
            "inactive_time": round(self.get_inactive_time(guild.id), 1),
            "should_disconnect": self.should_auto_disconnect(guild.id),
            "is_alone": guild.id in self.alone_since,
            "alone_duration": None,
            "connection_attempts": self.connection_attempts.get(guild.id, 0)
        }
        
        # Calculate alone duration if bot is alone
        if guild.id in self.alone_since:
            import time
            info["alone_duration"] = round(time.time() - self.alone_since[guild.id], 1)
        
        if vc and vc.channel:
            info["member_count"] = len(vc.channel.members)
            info["human_members"] = len([m for m in vc.channel.members if not m.bot])
            info["member_list"] = [m.display_name for m in vc.channel.members if not m.bot]
        
        return info
    
    def cleanup_guild(self, guild_id: int) -> None:
        """Clean up data for a guild."""
        self.last_channels.pop(guild_id, None)
        self.last_activity.pop(guild_id, None)
        self.connection_attempts.pop(guild_id, None)
        self.connection_status.pop(guild_id, None)
        self.alone_since.pop(guild_id, None)
        self.voice_events.pop(guild_id, None)
        self.logger.info(f"Cleaned up voice data for guild {guild_id}")
    
    async def emergency_disconnect_all(self) -> int:
        """Emergency disconnect from all voice channels."""
        disconnected = 0
        for guild_id, channel in self.last_channels.items():
            try:
                if channel.guild.voice_client:
                    await channel.guild.voice_client.disconnect()
                    disconnected += 1
            except Exception as e:
                self.logger.error(f"Error during emergency disconnect from guild {guild_id}: {e}")
        
        self.logger.info(f"Emergency disconnected from {disconnected} guilds")
        return disconnected
    
    def get_voice_monitoring_stats(self) -> Dict:
        """Get comprehensive voice monitoring statistics."""
        import time
        current_time = time.time()
        
        stats = {
            "total_guilds_monitored": len(self.last_activity),
            "currently_alone": len(self.alone_since),
            "total_connection_attempts": sum(self.connection_attempts.values()),
            "guilds_with_activity": 0,
            "average_inactive_time": 0,
            "longest_alone_duration": 0,
            "guild_details": []
        }
        
        total_inactive_time = 0
        for guild_id, last_activity in self.last_activity.items():
            inactive_time = current_time - last_activity
            total_inactive_time += inactive_time
            
            if inactive_time < self.config.auto_disconnect_timeout:
                stats["guilds_with_activity"] += 1
            
            # Check alone duration
            if guild_id in self.alone_since:
                alone_duration = current_time - self.alone_since[guild_id]
                stats["longest_alone_duration"] = max(stats["longest_alone_duration"], alone_duration)
        
        if self.last_activity:
            stats["average_inactive_time"] = total_inactive_time / len(self.last_activity)
        
        return stats
    
    def log_voice_event(self, guild_id: int, event_type: str, details: str = None):
        """Log voice events for monitoring."""
        import time
        
        if guild_id not in self.voice_events:
            self.voice_events[guild_id] = []
        
        event = {
            "timestamp": time.time(),
            "type": event_type,
            "details": details
        }
        
        # Keep only last 50 events per guild
        self.voice_events[guild_id].append(event)
        if len(self.voice_events[guild_id]) > 50:
            self.voice_events[guild_id] = self.voice_events[guild_id][-50:]
        
        self.logger.debug(f"Voice event in guild {guild_id}: {event_type} - {details}")
