# === PLAYLIST MANAGER ===
"""
Manages playlist saving, loading, and operations.
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..config import BotConfig
from ..exceptions import PlaylistError


class PlaylistManager:
    """Manages playlist operations."""
    
    def __init__(self, config: BotConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
    
    def _get_playlist_path(self, name: str) -> Path:
        """Get the full path for a playlist file."""
        return self.config.playlist_dir / f"{name}.json"
    
    def save_playlist(self, name: str, songs: List[Path], metadata: Optional[Dict] = None) -> bool:
        """Save a playlist to disk."""
        if not name or not name.strip():
            raise PlaylistError("Playlist name cannot be empty")
        
        # Sanitize playlist name
        safe_name = "".join(c for c in name if c.isalnum() or c in (' ', '-', '_')).strip()
        if not safe_name:
            raise PlaylistError("Invalid playlist name")
        
        try:
            playlist_data = {
                "name": safe_name,
                "songs": [str(song) for song in songs],
                "metadata": metadata or {},
                "song_count": len(songs),
                "created_at": self._get_timestamp(),
                "modified_at": self._get_timestamp()
            }
            
            playlist_path = self._get_playlist_path(safe_name)
            with open(playlist_path, 'w', encoding='utf-8') as f:
                json.dump(playlist_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Saved playlist '{safe_name}' with {len(songs)} songs")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to save playlist '{safe_name}': {e}")
            raise PlaylistError(f"Failed to save playlist: {e}")
    
    def load_playlist(self, name: str) -> Tuple[List[Path], Dict]:
        """Load a playlist from disk."""
        playlist_path = self._get_playlist_path(name)
        
        if not playlist_path.exists():
            raise PlaylistError(f"Playlist '{name}' not found")
        
        try:
            with open(playlist_path, 'r', encoding='utf-8') as f:
                playlist_data = json.load(f)
            
            songs = [Path(song_path) for song_path in playlist_data.get("songs", [])]
            metadata = playlist_data.get("metadata", {})
            
            # Filter out songs that no longer exist
            existing_songs = [song for song in songs if song.exists()]
            removed_count = len(songs) - len(existing_songs)
            
            if removed_count > 0:
                self.logger.warning(f"Playlist '{name}': {removed_count} songs no longer exist")
            
            self.logger.info(f"Loaded playlist '{name}' with {len(existing_songs)} songs")
            return existing_songs, metadata
            
        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON in playlist '{name}': {e}")
            raise PlaylistError(f"Playlist file is corrupted: {e}")
        except Exception as e:
            self.logger.error(f"Failed to load playlist '{name}': {e}")
            raise PlaylistError(f"Failed to load playlist: {e}")
    
    def delete_playlist(self, name: str) -> bool:
        """Delete a playlist."""
        playlist_path = self._get_playlist_path(name)
        
        if not playlist_path.exists():
            raise PlaylistError(f"Playlist '{name}' not found")
        
        try:
            playlist_path.unlink()
            self.logger.info(f"Deleted playlist '{name}'")
            return True
        except Exception as e:
            self.logger.error(f"Failed to delete playlist '{name}': {e}")
            raise PlaylistError(f"Failed to delete playlist: {e}")
    
    def list_playlists(self) -> List[Dict]:
        """List all available playlists with metadata."""
        playlists = []
        
        try:
            for playlist_file in self.config.playlist_dir.glob("*.json"):
                try:
                    with open(playlist_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    
                    playlist_info = {
                        "name": data.get("name", playlist_file.stem),
                        "song_count": data.get("song_count", len(data.get("songs", []))),
                        "created_at": data.get("created_at", "Unknown"),
                        "modified_at": data.get("modified_at", "Unknown"),
                        "file_size": f"{playlist_file.stat().st_size / 1024:.1f} KB"
                    }
                    playlists.append(playlist_info)
                    
                except Exception as e:
                    self.logger.warning(f"Could not read playlist {playlist_file.name}: {e}")
            
            # Sort by name
            playlists.sort(key=lambda x: x["name"].lower())
            
        except Exception as e:
            self.logger.error(f"Error listing playlists: {e}")
        
        return playlists
    
    def playlist_exists(self, name: str) -> bool:
        """Check if a playlist exists."""
        return self._get_playlist_path(name).exists()
    
    def rename_playlist(self, old_name: str, new_name: str) -> bool:
        """Rename a playlist."""
        if not self.playlist_exists(old_name):
            raise PlaylistError(f"Playlist '{old_name}' not found")
        
        if self.playlist_exists(new_name):
            raise PlaylistError(f"Playlist '{new_name}' already exists")
        
        try:
            # Load the playlist data
            songs, metadata = self.load_playlist(old_name)
            
            # Save with new name
            self.save_playlist(new_name, songs, metadata)
            
            # Delete old playlist
            self.delete_playlist(old_name)
            
            self.logger.info(f"Renamed playlist '{old_name}' to '{new_name}'")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to rename playlist '{old_name}' to '{new_name}': {e}")
            raise PlaylistError(f"Failed to rename playlist: {e}")
    
    def get_playlist_info(self, name: str) -> Dict:
        """Get detailed information about a playlist."""
        if not self.playlist_exists(name):
            raise PlaylistError(f"Playlist '{name}' not found")
        
        try:
            songs, metadata = self.load_playlist(name)
            playlist_path = self._get_playlist_path(name)
            
            # Calculate total duration and size if possible
            total_size = 0
            valid_songs = 0
            
            for song in songs:
                if song.exists():
                    total_size += song.stat().st_size
                    valid_songs += 1
            
            return {
                "name": name,
                "total_songs": len(songs),
                "valid_songs": valid_songs,
                "missing_songs": len(songs) - valid_songs,
                "total_size_mb": round(total_size / 1024 / 1024, 1),
                "file_size_kb": round(playlist_path.stat().st_size / 1024, 1),
                "metadata": metadata,
                "created_at": metadata.get("created_at", "Unknown"),
                "modified_at": metadata.get("modified_at", "Unknown")
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get playlist info for '{name}': {e}")
            raise PlaylistError(f"Failed to get playlist info: {e}")
    
    def _get_timestamp(self) -> str:
        """Get current timestamp as string."""
        from datetime import datetime
        return datetime.now().isoformat()
    
    def export_playlist_m3u(self, name: str, output_path: Optional[Path] = None) -> Path:
        """Export playlist to M3U format."""
        songs, metadata = self.load_playlist(name)
        
        if output_path is None:
            output_path = self.config.playlist_dir / f"{name}.m3u"
        
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write("#EXTM3U\n")
                f.write(f"# Playlist: {name}\n")
                f.write(f"# Created by BeaBot\n\n")
                
                for song in songs:
                    if song.exists():
                        f.write(f"#EXTINF:-1,{song.stem}\n")
                        f.write(f"{song}\n")
            
            self.logger.info(f"Exported playlist '{name}' to M3U format")
            return output_path
            
        except Exception as e:
            self.logger.error(f"Failed to export playlist '{name}' to M3U: {e}")
            raise PlaylistError(f"Failed to export playlist: {e}")
    
    def cleanup_playlists(self) -> Dict[str, int]:
        """Clean up playlists by removing non-existent songs."""
        results = {
            "playlists_cleaned": 0,
            "songs_removed": 0,
            "errors": 0
        }
        
        playlist_files = list(self.config.playlist_dir.glob("*.json"))
        
        for playlist_file in playlist_files:
            try:
                # Load playlist
                with open(playlist_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                original_songs = data.get("songs", [])
                existing_songs = []
                
                # Filter out non-existent songs
                for song_path in original_songs:
                    if Path(song_path).exists():
                        existing_songs.append(song_path)
                
                removed_count = len(original_songs) - len(existing_songs)
                
                if removed_count > 0:
                    # Update playlist data
                    data["songs"] = existing_songs
                    data["song_count"] = len(existing_songs)
                    data["modified_at"] = self._get_timestamp()
                    
                    # Save updated playlist
                    with open(playlist_file, 'w', encoding='utf-8') as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                    
                    results["playlists_cleaned"] += 1
                    results["songs_removed"] += removed_count
                    
                    self.logger.info(f"Cleaned playlist '{playlist_file.stem}': removed {removed_count} songs")
                
            except Exception as e:
                results["errors"] += 1
                self.logger.error(f"Error cleaning playlist '{playlist_file.stem}': {e}")
        
        return results
