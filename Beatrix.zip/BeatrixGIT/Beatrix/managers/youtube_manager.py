# === YOUTUBE DOWNLOADER ===
"""
Handles YouTube downloads with error handling and progress tracking.
"""

import asyncio
import contextlib
import io
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import yt_dlp

from ..config import BotConfig
from ..exceptions import YouTubeDownloadError


class YouTubeDownloader:
    """Handles YouTube downloads."""
    
    def __init__(self, config: BotConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.download_progress: Dict[str, Dict] = {}
        
        # Base yt-dlp options
        self.base_ydl_opts = {
            'format': 'bestaudio/best',
            'quiet': True,
            'no_warnings': True,
            'extractaudio': True,
            'audioformat': 'mp3',
            'audioquality': self.config.audio_quality,
            'outtmpl': str(self.config.yt_download_dir / '%(title)s_%(id)s.%(ext)s'),
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': self.config.audio_quality,
            }],
            'postprocessor_args': [
                '-ar', '44100',  # Sample rate
                '-ac', '2',      # Stereo
            ],
        }
    
    def _get_download_opts(self, search_query: bool = True) -> Dict:
        """Get yt-dlp options for download."""
        opts = self.base_ydl_opts.copy()
        if search_query:
            opts['default_search'] = 'ytsearch'
            opts['noplaylist'] = True
        return opts
    
    def _get_info_opts(self) -> Dict:
        """Get yt-dlp options for info extraction only."""
        opts = self.base_ydl_opts.copy()
        opts.update({
            'extract_flat': True,
            'skip_download': True,
        })
        return opts
    
    async def download_single(self, query: str, search: bool = True) -> Tuple[Optional[Path], Optional[str], Optional[Dict]]:
        """Download a single video from YouTube."""
        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self._download_sync, query, search)
        except Exception as e:
            self.logger.error(f"YouTube download failed for '{query}': {e}")
            raise YouTubeDownloadError(f"Download failed: {e}")
    
    def _download_sync(self, query: str, search: bool = True) -> Tuple[Optional[Path], Optional[str], Optional[Dict]]:
        """Synchronous download method."""
        try:
            # Capture output to prevent spam
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                with yt_dlp.YoutubeDL(self._get_download_opts(search)) as ydl:
                    # Extract info first
                    info = ydl.extract_info(query, download=False)
                    if 'entries' in info and info['entries']:
                        info = info['entries'][0]
                    
                    if not info:
                        return None, None, None
                    
                    # Download the video
                    ydl.download([info['webpage_url'] if 'webpage_url' in info else query])
                    
                    # Construct the expected output path
                    filename = ydl.prepare_filename(info)
                    filepath = Path(filename).with_suffix('.mp3')
                    
                    # Get video metadata
                    metadata = {
                        'title': info.get('title', 'Unknown'),
                        'uploader': info.get('uploader', 'Unknown'),
                        'duration': info.get('duration', 0),
                        'view_count': info.get('view_count', 0),
                        'upload_date': info.get('upload_date', ''),
                        'webpage_url': info.get('webpage_url', ''),
                        'id': info.get('id', ''),
                    }
                    
                    title = metadata['title']
                    
                    self.logger.info(f"Successfully downloaded: {title}")
                    return filepath, title, metadata
                    
        except yt_dlp.DownloadError as e:
            self.logger.error(f"yt-dlp download error: {e}")
            raise YouTubeDownloadError(f"Download failed: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error during download: {e}")
            raise YouTubeDownloadError(f"Unexpected error: {e}")
    
    async def get_video_info(self, query: str, search: bool = True) -> Optional[Dict]:
        """Get video information without downloading."""
        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self._get_info_sync, query, search)
        except Exception as e:
            self.logger.error(f"Failed to get video info for '{query}': {e}")
            return None
    
    def _get_info_sync(self, query: str, search: bool = True) -> Optional[Dict]:
        """Synchronous info extraction."""
        try:
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                with yt_dlp.YoutubeDL(self._get_info_opts()) as ydl:
                    info = ydl.extract_info(query, download=False)
                    if 'entries' in info and info['entries']:
                        info = info['entries'][0]
                    
                    if not info:
                        return None
                    
                    return {
                        'title': info.get('title', 'Unknown'),
                        'uploader': info.get('uploader', 'Unknown'),
                        'duration': info.get('duration', 0),
                        'view_count': info.get('view_count', 0),
                        'webpage_url': info.get('webpage_url', ''),
                        'thumbnail': info.get('thumbnail', ''),
                        'description': info.get('description', '')[:200] + '...' if info.get('description') else '',
                    }
        except Exception as e:
            self.logger.error(f"Error getting video info: {e}")
            return None
    
    async def download_playlist(self, playlist_url: str, max_items: int = 50) -> Tuple[List[Path], List[str], List[Dict], int]:
        """Download playlist with limits."""
        try:
            # First, get playlist info
            playlist_info = await self._get_playlist_info(playlist_url)
            if not playlist_info or 'entries' not in playlist_info:
                raise YouTubeDownloadError("Could not retrieve playlist information")
            
            entries = [entry for entry in playlist_info['entries'] if entry][:max_items]
            if not entries:
                raise YouTubeDownloadError("No valid videos found in playlist")
            
            # Download each video
            filepaths = []
            titles = []
            metadata_list = []
            failed = 0
            
            for idx, entry in enumerate(entries):
                try:
                    video_url = entry.get('webpage_url') or f"https://www.youtube.com/watch?v={entry['id']}"
                    filepath, title, metadata = await self.download_single(video_url, search=False)
                    
                    if filepath and title and metadata:
                        filepaths.append(filepath)
                        titles.append(title)
                        metadata_list.append(metadata)
                    else:
                        failed += 1
                        
                    # Yield control every few downloads
                    if idx % 2 == 0:
                        await asyncio.sleep(0.1)
                        
                except Exception as e:
                    self.logger.warning(f"Failed to download playlist item {idx + 1}: {e}")
                    failed += 1
            
            self.logger.info(f"Playlist download complete: {len(filepaths)} success, {failed} failed")
            return filepaths, titles, metadata_list, failed
            
        except Exception as e:
            self.logger.error(f"Playlist download failed: {e}")
            raise YouTubeDownloadError(f"Playlist download failed: {e}")
    
    async def _get_playlist_info(self, playlist_url: str) -> Optional[Dict]:
        """Get playlist information."""
        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self._get_playlist_info_sync, playlist_url)
        except Exception as e:
            self.logger.error(f"Failed to get playlist info: {e}")
            return None
    
    def _get_playlist_info_sync(self, playlist_url: str) -> Optional[Dict]:
        """Synchronous playlist info extraction."""
        opts = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': True,
            'ignoreerrors': True,
        }
        
        try:
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                with yt_dlp.YoutubeDL(opts) as ydl:
                    return ydl.extract_info(playlist_url, download=False)
        except Exception as e:
            self.logger.error(f"Error getting playlist info: {e}")
            return None
    
    def format_duration(self, seconds: int) -> str:
        """Format duration in seconds to MM:SS or HH:MM:SS."""
        if seconds <= 0:
            return "Unknown"
        
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        
        if hours > 0:
            return f"{hours}:{minutes:02d}:{seconds:02d}"
        else:
            return f"{minutes}:{seconds:02d}"
    
    def format_view_count(self, views: int) -> str:
        """Format view count with K/M/B suffixes."""
        if views < 1000:
            return str(views)
        elif views < 1_000_000:
            return f"{views / 1000:.1f}K"
        elif views < 1_000_000_000:
            return f"{views / 1_000_000:.1f}M"
        else:
            return f"{views / 1_000_000_000:.1f}B"
    
    def cleanup_failed_downloads(self) -> int:
        """Clean up any partial or failed downloads."""
        cleanup_count = 0
        try:
            for file_path in self.config.yt_download_dir.glob("*.part"):
                file_path.unlink()
                cleanup_count += 1
            
            for file_path in self.config.yt_download_dir.glob("*.temp"):
                file_path.unlink()
                cleanup_count += 1
                
            if cleanup_count > 0:
                self.logger.info(f"Cleaned up {cleanup_count} partial download files")
                
        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")
        
        return cleanup_count
