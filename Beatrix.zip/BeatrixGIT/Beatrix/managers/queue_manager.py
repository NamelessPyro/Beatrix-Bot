# === QUEUE MANAGER ===
"""
Manages music queues and history for guilds.
"""

import logging
from pathlib import Path
from typing import Dict, List, Optional

from ..config import BotConfig
from ..enums import RepeatMode
from ..exceptions import QueueFullError


class QueueManager:
    """Manages music queues for guilds."""
    
    def __init__(self, config: BotConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Guild-specific data
        self.queues: Dict[int, List[Path]] = {}
        self.history: Dict[int, List[Path]] = {}
        self.repeat_modes: Dict[int, RepeatMode] = {}
        self.current_songs: Dict[int, Optional[Path]] = {}
    
    def get_queue(self, guild_id: int) -> List[Path]:
        """Get queue for guild."""
        return self.queues.get(guild_id, [])
    
    def add_to_queue(self, guild_id: int, file_path: Path) -> None:
        """Add file to queue."""
        queue = self.queues.setdefault(guild_id, [])
        
        if len(queue) >= self.config.max_queue_length:
            raise QueueFullError(self.config.max_queue_length)
        
        queue.append(file_path)
        self.logger.info(f"Added {file_path.name} to queue for guild {guild_id}")
    
    def add_multiple_to_queue(self, guild_id: int, file_paths: List[Path]) -> int:
        """Add multiple files to queue. Returns number of files added."""
        queue = self.queues.setdefault(guild_id, [])
        available_slots = self.config.max_queue_length - len(queue)
        
        if available_slots <= 0:
            raise QueueFullError(self.config.max_queue_length)
        
        # Add as many as possible
        files_to_add = file_paths[:available_slots]
        queue.extend(files_to_add)
        
        added_count = len(files_to_add)
        self.logger.info(f"Added {added_count} files to queue for guild {guild_id}")
        return added_count
    
    def get_next_song(self, guild_id: int) -> Optional[Path]:
        """Get next song based on repeat mode."""
        queue = self.get_queue(guild_id)
        if not queue:
            return None
        
        repeat_mode = self.repeat_modes.get(guild_id, RepeatMode.OFF)
        current = self.current_songs.get(guild_id)
        
        if repeat_mode == RepeatMode.ONE and current:
            # Repeat current song
            return current
        elif repeat_mode == RepeatMode.ALL and queue:
            # Move first song to end and return it
            song = queue.pop(0)
            queue.append(song)
            next_song = queue[0] if queue else None
        else:  # RepeatMode.OFF
            # Normal progression
            next_song = queue.pop(0) if queue else None
        
        self.current_songs[guild_id] = next_song
        return next_song
    
    def peek_next_song(self, guild_id: int) -> Optional[Path]:
        """Peek at next song without removing it from queue."""
        queue = self.get_queue(guild_id)
        return queue[0] if queue else None
    
    def add_to_history(self, guild_id: int, file_path: Path) -> None:
        """Add song to history."""
        history = self.history.setdefault(guild_id, [])
        history.append(file_path)
        
        # Keep only last 20 songs in history
        if len(history) > 20:
            self.history[guild_id] = history[-20:]
    
    def get_history(self, guild_id: int) -> List[Path]:
        """Get playback history for guild."""
        return self.history.get(guild_id, [])
    
    def clear_queue(self, guild_id: int) -> int:
        """Clear queue for guild. Returns number of songs cleared."""
        queue = self.queues.get(guild_id, [])
        count = len(queue)
        self.queues[guild_id] = []
        self.current_songs[guild_id] = None
        self.logger.info(f"Cleared {count} songs from queue for guild {guild_id}")
        return count
    
    def remove_from_queue(self, guild_id: int, index: int) -> Optional[Path]:
        """Remove song at index from queue."""
        queue = self.get_queue(guild_id)
        if 0 <= index < len(queue):
            removed = queue.pop(index)
            self.logger.info(f"Removed {removed.name} from queue for guild {guild_id}")
            return removed
        return None
    
    def skip_to_index(self, guild_id: int, index: int) -> List[Path]:
        """Skip to specific index in queue. Returns skipped songs."""
        queue = self.get_queue(guild_id)
        if index < 0 or index >= len(queue):
            return []
        
        skipped = queue[:index]
        self.queues[guild_id] = queue[index:]
        self.logger.info(f"Skipped {len(skipped)} songs for guild {guild_id}")
        return skipped
    
    def shuffle_queue(self, guild_id: int) -> bool:
        """Shuffle the queue."""
        queue = self.get_queue(guild_id)
        if len(queue) <= 1:
            return False
        
        import random
        random.shuffle(queue)
        self.logger.info(f"Shuffled queue for guild {guild_id}")
        return True
    
    def set_repeat_mode(self, guild_id: int, mode: RepeatMode) -> None:
        """Set repeat mode for guild."""
        self.repeat_modes[guild_id] = mode
        self.logger.info(f"Set repeat mode to {mode} for guild {guild_id}")
    
    def get_repeat_mode(self, guild_id: int) -> RepeatMode:
        """Get repeat mode for guild."""
        return self.repeat_modes.get(guild_id, RepeatMode.OFF)
    
    def get_queue_info(self, guild_id: int) -> Dict:
        """Get comprehensive queue information."""
        queue = self.get_queue(guild_id)
        history = self.get_history(guild_id)
        current = self.current_songs.get(guild_id)
        repeat_mode = self.get_repeat_mode(guild_id)
        
        total_size = sum(f.stat().st_size for f in queue if f.exists())
        
        return {
            "queue_length": len(queue),
            "history_length": len(history),
            "current_song": current.name if current else None,
            "repeat_mode": repeat_mode.value,
            "total_size_mb": round(total_size / 1024 / 1024, 1),
            "queue_full": len(queue) >= self.config.max_queue_length
        }
    
    def cleanup_guild(self, guild_id: int) -> None:
        """Clean up all data for a guild."""
        self.queues.pop(guild_id, None)
        self.history.pop(guild_id, None)
        self.repeat_modes.pop(guild_id, None)
        self.current_songs.pop(guild_id, None)
        self.logger.info(f"Cleaned up data for guild {guild_id}")
