# === MUSIC FILE MANAGER ===
"""
Handles music file operations and searching.
"""

import logging
import random
from pathlib import Path
from typing import Dict, List, Optional

from ..config import BotConfig
from ..enums import AudioFormat
from ..exceptions import NoSongsFoundError


class MusicFileManager:
    """Handles music file operations."""
    
    def __init__(self, config: BotConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self._cache: Optional[List[Path]] = None
        self._cache_dirty = True
    
    def _get_supported_extensions(self) -> List[str]:
        """Get list of supported audio file extensions."""
        return [f".{fmt.value}" for fmt in AudioFormat]
    
    def find_audio_files(self, refresh_cache: bool = False) -> List[Path]:
        """Find all audio files in the music directory."""
        if not refresh_cache and not self._cache_dirty and self._cache is not None:
            return self._cache
        
        try:
            audio_files = []
            extensions = self._get_supported_extensions()
            
            for file_path in self.config.music_dir.rglob("*"):
                if file_path.is_file() and file_path.suffix.lower() in extensions:
                    audio_files.append(file_path)
            
            self._cache = audio_files
            self._cache_dirty = False
            self.logger.info(f"Found {len(audio_files)} audio files")
            return audio_files
            
        except Exception as e:
            self.logger.error(f"Error finding audio files: {e}")
            return []
    
    def search_by_keyword(self, keyword: str) -> Optional[Path]:
        """Search for audio file by keyword."""
        keyword_lower = keyword.lower()
        files = self.find_audio_files()
        
        # First try exact filename match
        for file_path in files:
            if keyword_lower == file_path.stem.lower():
                return file_path
        
        # Then try partial match
        for file_path in files:
            if keyword_lower in file_path.stem.lower():
                return file_path
        
        return None
    
    def search_multiple(self, keyword: str, limit: int = 10) -> List[Path]:
        """Search for multiple files matching keyword."""
        keyword_lower = keyword.lower()
        files = self.find_audio_files()
        matches = []
        
        for file_path in files:
            if keyword_lower in file_path.stem.lower():
                matches.append(file_path)
                if len(matches) >= limit:
                    break
        
        return matches
    
    def get_files_by_artist(self) -> Dict[str, List[Path]]:
        """Group files by artist (directory name)."""
        artists = {}
        files = self.find_audio_files()
        
        for file_path in files:
            # Use parent directory name as artist
            artist = file_path.parent.name
            if artist not in artists:
                artists[artist] = []
            artists[artist].append(file_path)
        
        return artists
    
    def get_files_by_letter(self, letter: str) -> List[Path]:
        """Get files starting with a specific letter."""
        if not letter or len(letter) != 1:
            return []
        
        letter_lower = letter.lower()
        files = self.find_audio_files()
        
        return [f for f in files if f.stem.lower().startswith(letter_lower)]
    
    def get_files_in_folder(self, folder_name: str) -> List[Path]:
        """Get files in a specific folder."""
        folder_path = self.config.music_dir / folder_name
        if not folder_path.exists() or not folder_path.is_dir():
            raise NoSongsFoundError(f"Folder '{folder_name}' not found")
        
        extensions = self._get_supported_extensions()
        files = []
        
        for file_path in folder_path.iterdir():
            if file_path.is_file() and file_path.suffix.lower() in extensions:
                files.append(file_path)
        
        return files
    
    def get_random_files(self, count: int) -> List[Path]:
        """Get random audio files."""
        files = self.find_audio_files()
        if not files:
            raise NoSongsFoundError("No audio files found")
        
        return random.sample(files, min(count, len(files)))
    
    def get_relative_path(self, file_path: Path) -> str:
        """Get path relative to music directory."""
        try:
            return str(file_path.relative_to(self.config.music_dir))
        except ValueError:
            return str(file_path)
    
    def invalidate_cache(self):
        """Mark the file cache as dirty."""
        self._cache_dirty = True
    
    def get_file_info(self, file_path: Path) -> Dict[str, str]:
        """Get basic file information."""
        return {
            "name": file_path.stem,
            "extension": file_path.suffix,
            "artist": file_path.parent.name,
            "relative_path": self.get_relative_path(file_path),
            "size": f"{file_path.stat().st_size / 1024 / 1024:.1f} MB" if file_path.exists() else "Unknown"
        }
    
    def get_library_stats(self) -> dict:
        """Get library statistics."""
        files = self.find_audio_files()
        total_size = sum(file.stat().st_size for file in files if file.exists())
        
        # Group by format
        formats = {}
        for file in files:
            ext = file.suffix.lower()
            formats[ext] = formats.get(ext, 0) + 1
        
        return {
            "total_files": len(files),
            "total_size_mb": total_size / (1024 * 1024),
            "formats": formats,
            "directories": len(set(file.parent for file in files))
        }
    
    def get_all_files(self) -> List[Path]:
        """Get all audio files (alias for find_audio_files for compatibility)."""
        return self.find_audio_files()
