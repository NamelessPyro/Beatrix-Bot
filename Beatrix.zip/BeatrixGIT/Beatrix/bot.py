# === BEATRIX BOT ===
"""
Improved Discord Music Bot with modular architecture.
"""

import asyncio
import logging
import os
import signal
import sys
from pathlib import Path

import discord
from discord.ext import commands

# Import our modules
from .config import BotConfig
from .managers import (
    MusicFileManager,
    QueueManager,
    VoiceConnectionManager,
    YouTubeDownloader,
    PlaylistManager
)
from .music_player import MusicPlayer
from .exceptions import BotError


class BeatrixBot(commands.Bot):
    """Main bot class with improved architecture."""
    
    def __init__(self, config: BotConfig):
        self.config = config
        
        # Setup intents
        intents = discord.Intents.default()
        intents.message_content = True
        intents.voice_states = True
        intents.guilds = True
        
        super().__init__(
            command_prefix=config.command_prefix,
            intents=intents,
            help_command=None  # We'll implement our own
        )
        
        # Initialize logging
        self.setup_logging()
        self.logger = logging.getLogger(__name__)
        
        # Initialize managers
        self.file_manager = MusicFileManager(config)
        self.queue_manager = QueueManager(config)
        self.voice_manager = VoiceConnectionManager(config)
        self.youtube_downloader = YouTubeDownloader(config)
        self.playlist_manager = PlaylistManager(config)
        
        # Initialize music player
        self.music_player = MusicPlayer(config, self.queue_manager, self.voice_manager)
        
        # Setup signal handlers for graceful shutdown
        self.setup_signal_handlers()
        
        # Track active views per guild
        self.active_views = {}
        
        # Track start time for uptime calculation
        from datetime import datetime
        self.start_time = datetime.now()
    
    def setup_logging(self):
        """Configure logging system."""
        # Create logs directory if it doesn't exist
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)
        
        # Setup logging configuration
        logging.basicConfig(
            level=getattr(logging, self.config.log_level),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / self.config.log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
        
        # Set discord.py logging level to WARNING to reduce spam
        logging.getLogger('discord').setLevel(logging.WARNING)
        logging.getLogger('discord.http').setLevel(logging.WARNING)
    
    def setup_signal_handlers(self):
        """Setup graceful shutdown handlers."""
        def shutdown_handler(signum, frame):
            self.logger.info(f"Received signal {signum}, initiating shutdown...")
            asyncio.create_task(self.shutdown())
        
        signal.signal(signal.SIGINT, shutdown_handler)
        signal.signal(signal.SIGTERM, shutdown_handler)
    
    async def setup_hook(self):
        """Setup hook called when bot is starting."""
        self.logger.info("Setting up bot...")
        
        # Load command cogs
        await self.load_cogs()
        
        # Start background tasks
        self.loop.create_task(self.auto_disconnect_task())
        
        self.logger.info("Bot setup complete")
    
    async def load_cogs(self):
        """Load all command cogs."""
        cogs = [
            'commands.music',
            'commands.queue',
            'commands.library',
            'commands.playlist',
            'commands.admin',
            'commands.help'
        ]
        
        for cog in cogs:
            try:
                await self.load_extension(f'Beatrix.{cog}')
                self.logger.info(f"Loaded cog: {cog}")
            except Exception as e:
                self.logger.error(f"Failed to load cog {cog}: {e}")
    
    async def on_ready(self):
        """Called when bot is ready."""
        self.logger.info(f"Bot ready as {self.user}")
        self.logger.info(f"Connected to {len(self.guilds)} guilds")

        # Print servers and connected channels
        print("\n--- BeatrixBot is in the following servers and channels ---")
        for guild in self.guilds:
            print(f"Server: {guild.name}")
            vc = guild.voice_client
            if vc and vc.channel:
                print(f"  Connected to voice channel: {vc.channel.name}")
            else:
                print("  Not connected to any voice channel.")
        print("---------------------------------------------------------\n")
        self.logger.info("Printed server and channel info to console.")

        # Sync slash commands
        try:
            synced = await self.tree.sync()
            self.logger.info(f"Synced {len(synced)} slash commands")
        except Exception as e:
            self.logger.error(f"Failed to sync commands: {e}")

        # Set bot status
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.listening,
                name="music | /help"
            )
        )
    
    async def on_voice_state_update(self, member, before, after):
        """Handle voice state updates for auto-reconnection and monitoring."""
        # Monitor all voice state changes for better connection tracking
        guild_id = member.guild.id
        
        # Only process bot's own voice state changes for reconnection logic
        if member == self.user:
            await self._handle_bot_voice_update(member, before, after)
        
        # Monitor all members for voice channel activity tracking
        await self._monitor_voice_activity(member, before, after)
    
    async def _handle_bot_voice_update(self, member, before, after):
        """Handle the bot's own voice state changes."""
        guild_id = member.guild.id
        
        # Bot was disconnected from voice channel
        if before.channel and not after.channel:
            self.logger.info(f"Bot disconnected from voice in {member.guild.name}")
            
            # Update voice manager state
            self.voice_manager.cleanup_guild(guild_id)
            
            # Check if there's a queue and attempt to reconnect
            queue = self.queue_manager.get_queue(guild_id)
            if queue:
                self.logger.info(f"Queue exists for {member.guild.name}, attempting reconnection...")
                
                # Try to reconnect after a short delay
                await asyncio.sleep(2)
                vc = await self.voice_manager.attempt_reconnection(guild_id, has_queue=True)
                if vc:
                    # Find a text channel to resume playback
                    text_channel = await self._find_notification_channel(member.guild)
                    
                    # Resume playback
                    if text_channel:
                        await text_channel.send("🔄 Reconnected and resuming playback...")
                        await self.music_player.play_next(member.guild, text_channel)
        
        # Bot connected to a voice channel
        elif not before.channel and after.channel:
            self.voice_manager.last_channels[guild_id] = after.channel
            self.voice_manager.update_activity(guild_id)
            self.logger.info(f"Connected to {after.channel.name} in {member.guild.name}")
        
        # Bot moved between voice channels
        elif before.channel and after.channel and before.channel != after.channel:
            self.voice_manager.last_channels[guild_id] = after.channel
            self.voice_manager.update_activity(guild_id)
            self.logger.info(f"Moved from {before.channel.name} to {after.channel.name} in {member.guild.name}")
    
    async def _monitor_voice_activity(self, member, before, after):
        """Monitor voice channel activity for all members."""
        guild_id = member.guild.id
        
        # Skip bot monitoring (handled separately)
        if member == self.user:
            return
        
        # Check if someone joined the same channel as the bot
        if after.channel and self.user in after.channel.members:
            self.voice_manager.update_activity(guild_id)
            self.logger.debug(f"{member.display_name} joined bot's voice channel in {member.guild.name}")
        
        # Check if the bot is alone in a voice channel
        if before.channel and self.user in before.channel.members:
            # Count non-bot members in the channel
            human_members = [m for m in before.channel.members if not m.bot]
            if len(human_members) == 0:
                self.logger.info(f"Bot is now alone in {before.channel.name} in {member.guild.name}")
                # Don't auto-disconnect immediately, but note the time
                self.voice_manager.update_activity(guild_id, alone=True)
    
    async def _find_notification_channel(self, guild):
        """Find a suitable text channel for notifications."""
        # Look for common notification channel names first
        priority_names = ['music', 'bot-commands', 'commands', 'general', 'main']
        
        for name in priority_names:
            for channel in guild.text_channels:
                if name in channel.name.lower() and channel.permissions_for(guild.me).send_messages:
                    return channel
        
        # Fall back to any channel we can send messages to
        for channel in guild.text_channels:
            if channel.permissions_for(guild.me).send_messages:
                return channel
        
        return None
    
    async def on_guild_join(self, guild):
        """Called when bot joins a guild."""
        self.logger.info(f"Joined guild: {guild.name} (ID: {guild.id})")
        
        # Send welcome message if possible
        try:
            # Find a suitable channel to send welcome message
            channel = None
            for ch in guild.text_channels:
                if ch.permissions_for(guild.me).send_messages:
                    channel = ch
                    break
            
            if channel:
                embed = discord.Embed(
                    title="👋 Hello!",
                    description="Thanks for adding me to your server! Use `/help` to see all available commands.",
                    color=discord.Color.green()
                )
                embed.add_field(
                    name="Getting Started",
                    value="1. Join a voice channel\n2. Use `/play` to play music\n3. Use `/queue` to manage your playlist",
                    inline=False
                )
                await channel.send(embed=embed)
        except Exception as e:
            self.logger.error(f"Error sending welcome message: {e}")
    
    async def on_guild_remove(self, guild):
        """Called when bot leaves a guild."""
        self.logger.info(f"Left guild: {guild.name} (ID: {guild.id})")
        
        # Cleanup guild data
        self.queue_manager.cleanup_guild(guild.id)
        self.voice_manager.cleanup_guild(guild.id)
        self.active_views.pop(guild.id, None)
    
    async def on_command_error(self, ctx, error):
        """Handle command errors."""
        if isinstance(error, commands.CommandNotFound):
            return  # Ignore unknown commands
        
        self.logger.error(f"Command error in {ctx.command}: {error}")
        
        if isinstance(error, BotError):
            await ctx.send(f"❌ {error}")
        else:
            await ctx.send("❌ An unexpected error occurred.")
    
    async def auto_disconnect_task(self):
        """Auto-disconnect task with improved logic."""
        await self.wait_until_ready()
        
        while not self.is_closed():
            try:
                for guild in self.guilds:
                    vc = guild.voice_client
                    if not vc:
                        continue
                    
                    guild_id = guild.id
                    queue = self.queue_manager.get_queue(guild_id)
                    
                    # Update activity if playing or queue exists
                    if vc.is_playing() or queue:
                        self.voice_manager.update_activity(guild_id)
                        continue
                    
                    # Check for auto-disconnect
                    if self.voice_manager.should_auto_disconnect(guild_id):
                        try:
                            await self.voice_manager.disconnect_from_guild(guild)
                            self.logger.info(f"Auto-disconnected from {guild.name} after inactivity")
                            
                            # Try to send notification
                            for channel in guild.text_channels:
                                if channel.permissions_for(guild.me).send_messages:
                                    await channel.send("🔇 Disconnected due to inactivity (5 minutes)")
                                    break
                        except Exception as e:
                            self.logger.error(f"Auto-disconnect error for {guild.name}: {e}")
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                self.logger.error(f"Auto-disconnect task error: {e}")
                await asyncio.sleep(60)  # Longer sleep on error
    
    async def shutdown(self):
        """Graceful shutdown procedure."""
        self.logger.info("Starting shutdown procedure...")
        
        try:
            # Disconnect from all voice channels
            disconnected = await self.voice_manager.emergency_disconnect_all()
            self.logger.info(f"Disconnected from {disconnected} voice channels")
            
            # Close the bot connection
            await self.close()
            
        except Exception as e:
            self.logger.error(f"Error during shutdown: {e}")
        finally:
            self.logger.info("Shutdown complete")
    
    async def get_bot_stats(self) -> dict:
        """Get bot statistics."""
        total_songs = len(self.file_manager.find_audio_files())
        total_queued = sum(len(queue) for queue in self.queue_manager.queues.values())
        connected_guilds = len([g for g in self.guilds if g.voice_client])
        
        return {
            "guilds": len(self.guilds),
            "connected_voice": connected_guilds,
            "total_songs": total_songs,
            "total_queued": total_queued,
            "uptime": "Not implemented",  # TODO: Track uptime
            "memory_usage": "Not implemented"  # TODO: Track memory
        }


async def create_bot(token: str = None) -> BeatrixBot:
    """Create and configure the bot."""
    # Load configuration
    config = BotConfig.from_env()
    
    # Create bot instance
    bot = BeatrixBot(config)
    
    # Get token from environment or parameter
    if not token:
        token = os.getenv("DISCORD_TOKEN")
    
    if not token:
        raise ValueError("Discord token not provided. Set DISCORD_TOKEN environment variable.")
    
    return bot, token


async def main():
    """Main entry point."""
    try:
        bot, token = await create_bot()
        await bot.start(token)
    except KeyboardInterrupt:
        print("Bot stopped by user")
    except Exception as e:
        print(f"Error starting bot: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
