# === UTILITY ENUMS ===
"""
Enums and constants for BeaBot.
"""

from enum import Enum


class RepeatMode(Enum):
    """Enum for repeat modes."""
    OFF = "off"
    ONE = "one"
    ALL = "all"
    
    def __str__(self):
        return self.value
    
    @classmethod
    def from_string(cls, value: str) -> 'RepeatMode':
        """Create RepeatMode from string."""
        for mode in cls:
            if mode.value.lower() == value.lower():
                return mode
        raise ValueError(f"Invalid repeat mode: {value}")


class AudioFormat(Enum):
    """Supported audio formats."""
    MP3 = "mp3"
    WAV = "wav"
    FLAC = "flac"
    M4A = "m4a"
    
    def __str__(self):
        return self.value


class LogLevel(Enum):
    """Logging levels."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"
