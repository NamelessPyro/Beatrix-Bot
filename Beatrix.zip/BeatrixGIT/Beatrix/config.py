# === CONFIGURATION ===
"""
Centralized configuration management for BeaBot.
"""

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# Try to load environment variables from .env file
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # dotenv not installed, try manual .env loading
    env_file = Path(__file__).parent.parent / '.env'
    if env_file.exists():
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key.strip()] = value.strip()


@dataclass
class BotConfig:
    """Centralized configuration management."""
    # Paths
    music_dir: Path = Path("D:/Music")
    yt_download_dir: Optional[Path] = None
    playlist_dir: Optional[Path] = None
    ffmpeg_path: Path = Path("d:/BeaBot/ffmpeg/bin/ffmpeg.exe")
    
    # Bot Settings
    max_queue_length: int = 100
    auto_disconnect_timeout: int = 300  # 5 minutes in seconds
    command_prefix: str = "!"
    bot_version: str = "2.0.0"
    owner_id: Optional[int] = None
    
    # Logging
    log_level: str = "INFO"
    log_file: str = "beatrix.log"
    
    # Audio Settings
    audio_quality: str = "192"
    reconnect_attempts: int = 3
    
    def __post_init__(self):
        """Initialize derived paths and create directories."""
        self.yt_download_dir = self.music_dir / "VenturingSalinder"
        self.playlist_dir = self.music_dir / "Playlists"
        
        # Ensure directories exist
        for dir_path in [self.music_dir, self.yt_download_dir, self.playlist_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)
    
    @classmethod
    def from_env(cls) -> 'BotConfig':
        """Create config from environment variables."""
        config = cls()
        
        # Override with environment variables if they exist
        if music_dir := os.getenv("MUSIC_DIR"):
            config.music_dir = Path(music_dir)
        
        if ffmpeg_path := os.getenv("FFMPEG_PATH"):
            config.ffmpeg_path = Path(ffmpeg_path)
        
        if max_queue := os.getenv("MAX_QUEUE_LENGTH"):
            config.max_queue_length = int(max_queue)
        
        if timeout := os.getenv("AUTO_DISCONNECT_TIMEOUT"):
            config.auto_disconnect_timeout = int(timeout)
        
        if log_level := os.getenv("LOG_LEVEL"):
            config.log_level = log_level
        
        if owner_id := os.getenv("OWNER_ID"):
            config.owner_id = int(owner_id)
        
        # Re-run post_init to update derived paths
        config.__post_init__()
        return config
    
    def reload(self):
        """Reload configuration from environment variables."""
        new_config = self.from_env()
        # Update current instance with new values
        for field_name, field_value in new_config.__dict__.items():
            setattr(self, field_name, field_value)
