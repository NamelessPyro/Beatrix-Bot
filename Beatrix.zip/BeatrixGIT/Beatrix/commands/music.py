# === MUSIC COMMANDS ===
"""
Music playback and control commands.
"""

import asyncio
import logging
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands

from ..exceptions import QueueFullError, NoSongsFoundError, VoiceConnectionError, YouTubeDownloadError
from ..ui import PagedEmbedView


class MusicCommands(commands.Cog):
    """Music playback commands."""
    
    def __init__(self, bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
    
    @app_commands.command(name="join", description="Join your voice channel")
    async def join(self, interaction: discord.Interaction):
        """Join the user's voice channel."""
        # Defer response to prevent timeout
        await interaction.response.defer()
        
        if not interaction.user.voice:
            await interaction.edit_original_response(content="❌ You need to join a voice channel first!")
            return
        
        try:
            vc = await self.bot.voice_manager.connect_to_channel(interaction.user.voice.channel)
            embed = discord.Embed(
                title="✅ Joined Voice Channel",
                description=f"Connected to **{interaction.user.voice.channel.name}**",
                color=discord.Color.green()
            )
            await interaction.edit_original_response(embed=embed)
            
        except VoiceConnectionError as e:
            await interaction.edit_original_response(content=f"❌ {e}")
        except Exception as e:
            self.logger.error(f"Error joining voice channel: {e}")
            await interaction.edit_original_response(content="❌ An error occurred while joining the voice channel.")
    
    @app_commands.command(name="leave", description="Leave the voice channel")
    async def leave(self, interaction: discord.Interaction):
        """Leave the voice channel."""
        await interaction.response.defer()
        
        if not interaction.guild.voice_client:
            await interaction.edit_original_response(content="❌ I'm not in a voice channel.")
            return
        
        try:
            # Stop playback and clear queue
            await self.bot.music_player.stop_playback(interaction.guild, clear_queue=True)
            
            # Disconnect
            await self.bot.voice_manager.disconnect_from_guild(interaction.guild)
            
            embed = discord.Embed(
                title="👋 Left Voice Channel",
                description="Disconnected and cleared the queue.",
                color=discord.Color.orange()
            )
            await interaction.edit_original_response(embed=embed)
            
        except Exception as e:
            self.logger.error(f"Error leaving voice channel: {e}")
            await interaction.response.send_message("❌ An error occurred while leaving the voice channel.", ephemeral=True)
    
    @app_commands.command(name="play", description="Play a song by searching your music library")
    @app_commands.describe(keyword="Search keyword for your song")
    async def play(self, interaction: discord.Interaction, keyword: str):
        """Play a song from the music library."""
        guild_id = interaction.guild.id
        
        # Check voice connection
        vc = interaction.guild.voice_client
        if not vc:
            if not interaction.user.voice:
                await interaction.response.send_message("❌ Join a voice channel first!", ephemeral=True)
                return
            
            try:
                vc = await self.bot.voice_manager.connect_to_channel(interaction.user.voice.channel)
            except VoiceConnectionError as e:
                await interaction.response.send_message(f"❌ {e}", ephemeral=True)
                return
        
        try:
            # Search for the song
            song_path = self.bot.file_manager.search_by_keyword(keyword)
            if not song_path:
                await interaction.response.send_message(f"❌ No song found matching '{keyword}'", ephemeral=True)
                return
            
            # Add to queue
            self.bot.queue_manager.add_to_queue(guild_id, song_path)
            
            # Start playback or add to queue
            if vc.is_playing() or vc.is_paused():
                embed = discord.Embed(
                    title="➕ Added to Queue",
                    description=f"**{song_path.stem}**",
                    color=discord.Color.blue()
                )
                queue_info = self.bot.queue_manager.get_queue_info(guild_id)
                embed.add_field(name="Queue Position", value=f"{queue_info['queue_length']}", inline=True)
                await interaction.response.send_message(embed=embed)
            else:
                await interaction.response.send_message(f"🎵 Playing: **{song_path.stem}**")
                await self.bot.music_player.play_next(interaction.guild, interaction.channel)
        
        except QueueFullError as e:
            await interaction.response.send_message(f"❌ {e}", ephemeral=True)
        except Exception as e:
            self.logger.error(f"Error in play command: {e}")
            await interaction.response.send_message("❌ An error occurred while processing your request.", ephemeral=True)
    
    @app_commands.command(name="yt", description="Download and play a song from YouTube")
    @app_commands.describe(query="Search term or YouTube URL")
    async def yt(self, interaction: discord.Interaction, query: str):
        """Download and play from YouTube."""
        guild_id = interaction.guild.id
        
        # Check voice connection
        vc = interaction.guild.voice_client
        if not vc:
            if not interaction.user.voice:
                await interaction.response.send_message("❌ Join a voice channel first!", ephemeral=True)
                return
            
            try:
                vc = await self.bot.voice_manager.connect_to_channel(interaction.user.voice.channel)
            except VoiceConnectionError as e:
                await interaction.response.send_message(f"❌ {e}", ephemeral=True)
                return
        
        # Send initial response
        await interaction.response.send_message(f"🔍 Searching YouTube for: `{query}`...")
        
        try:
            # Download the song
            filepath, title, metadata = await self.bot.youtube_downloader.download_single(query)
            
            if not filepath or not title:
                await interaction.followup.send("❌ Failed to download from YouTube.")
                return
            
            # Add duration info if available
            duration_str = ""
            if metadata and metadata.get('duration'):
                duration_str = f" ({self.bot.youtube_downloader.format_duration(metadata['duration'])})"
            
            # Add to queue
            self.bot.queue_manager.add_to_queue(guild_id, filepath)
            
            # Create embed with metadata
            embed = discord.Embed(
                title="📥 Downloaded from YouTube",
                description=f"**{title}**{duration_str}",
                color=discord.Color.red()
            )
            
            if metadata:
                if metadata.get('uploader'):
                    embed.add_field(name="Channel", value=metadata['uploader'], inline=True)
                if metadata.get('view_count'):
                    views = self.bot.youtube_downloader.format_view_count(metadata['view_count'])
                    embed.add_field(name="Views", value=views, inline=True)
            
            # Start playback or show queue position
            if vc.is_playing() or vc.is_paused():
                queue_info = self.bot.queue_manager.get_queue_info(guild_id)
                embed.add_field(name="Queue Position", value=f"{queue_info['queue_length']}", inline=True)
                await interaction.followup.send(embed=embed)
            else:
                await interaction.followup.send(embed=embed)
                await self.bot.music_player.play_next(interaction.guild, interaction.channel)
        
        except QueueFullError as e:
            await interaction.followup.send(f"❌ {e}")
        except YouTubeDownloadError as e:
            await interaction.followup.send(f"❌ {e}")
        except Exception as e:
            self.logger.error(f"Error in yt command: {e}")
            await interaction.followup.send("❌ An error occurred during YouTube download.")
    
    @app_commands.command(name="pause", description="Pause the current song")
    async def pause(self, interaction: discord.Interaction):
        """Pause playback."""
        if await self.bot.music_player.pause_playback(interaction.guild):
            embed = discord.Embed(
                title="⏸️ Paused",
                description="Playback paused.",
                color=discord.Color.orange()
            )
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message("❌ Nothing is currently playing.", ephemeral=True)
    
    @app_commands.command(name="resume", description="Resume the paused song")
    async def resume(self, interaction: discord.Interaction):
        """Resume playback."""
        if await self.bot.music_player.resume_playback(interaction.guild):
            embed = discord.Embed(
                title="▶️ Resumed",
                description="Playback resumed.",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message("❌ Nothing is paused.", ephemeral=True)
    
    @app_commands.command(name="stop", description="Stop playback and clear the queue")
    async def stop(self, interaction: discord.Interaction):
        """Stop playback and clear queue."""
        if await self.bot.music_player.stop_playback(interaction.guild, clear_queue=True):
            cleared_count = self.bot.queue_manager.clear_queue(interaction.guild.id)
            
            embed = discord.Embed(
                title="⏹️ Stopped",
                description=f"Playback stopped and cleared {cleared_count} songs from queue.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message("❌ Nothing to stop.", ephemeral=True)
    
    @app_commands.command(name="skip", description="Skip the current song")
    async def skip(self, interaction: discord.Interaction):
        """Skip current song."""
        if await self.bot.music_player.skip_current_song(interaction.guild):
            embed = discord.Embed(
                title="⏭️ Skipped",
                description="Skipped to next song.",
                color=discord.Color.blue()
            )
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message("❌ Nothing to skip.", ephemeral=True)
    
    @app_commands.command(name="nowplaying", description="Show the currently playing song")
    async def nowplaying(self, interaction: discord.Interaction):
        """Show currently playing song."""
        playback_info = self.bot.music_player.get_playback_info(interaction.guild)
        
        if not playback_info["current_song"]:
            await interaction.response.send_message("❌ Nothing is currently playing.", ephemeral=True)
            return
        
        embed = discord.Embed(
            title="🎵 Now Playing",
            description=f"**{playback_info['current_song']}**",
            color=discord.Color.green()
        )
        
        # Add playback status
        status = "▶️ Playing" if playback_info["is_playing"] else "⏸️ Paused"
        embed.add_field(name="Status", value=status, inline=True)
        
        # Add queue info
        embed.add_field(name="Queue", value=f"{playback_info['queue_length']} songs", inline=True)
        embed.add_field(name="Repeat", value=playback_info["repeat_mode"], inline=True)
        
        if playback_info["voice_channel"]:
            embed.add_field(name="Voice Channel", value=playback_info["voice_channel"], inline=True)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="random", description="Add random songs to the queue")
    @app_commands.describe(count="Number of random songs to add (default: 20)")
    async def random(self, interaction: discord.Interaction, count: int = 20):
        """Add random songs to queue."""
        guild_id = interaction.guild.id
        
        # Limit count
        count = max(1, min(count, 50))
        
        # Check voice connection
        vc = interaction.guild.voice_client
        if not vc:
            if not interaction.user.voice:
                await interaction.response.send_message("❌ Join a voice channel first!", ephemeral=True)
                return
            
            try:
                vc = await self.bot.voice_manager.connect_to_channel(interaction.user.voice.channel)
            except VoiceConnectionError as e:
                await interaction.response.send_message(f"❌ {e}", ephemeral=True)
                return
        
        try:
            # Get random files
            random_files = self.bot.file_manager.get_random_files(count)
            
            # Add to queue
            added_count = self.bot.queue_manager.add_multiple_to_queue(guild_id, random_files)
            
            embed = discord.Embed(
                title="🎲 Random Songs Added",
                description=f"Added {added_count} random songs to the queue.",
                color=discord.Color.purple()
            )
            
            if added_count < count:
                embed.add_field(
                    name="Note",
                    value=f"Only {added_count} of {count} songs could be added due to queue limit.",
                    inline=False
                )
            
            await interaction.response.send_message(embed=embed)
            
            # Start playback if nothing is playing
            if not vc.is_playing() and not vc.is_paused():
                await self.bot.music_player.play_next(interaction.guild, interaction.channel)
        
        except NoSongsFoundError as e:
            await interaction.response.send_message(f"❌ {e}", ephemeral=True)
        except QueueFullError as e:
            await interaction.response.send_message(f"❌ {e}", ephemeral=True)
        except Exception as e:
            self.logger.error(f"Error in random command: {e}")
            await interaction.response.send_message("❌ An error occurred while adding random songs.", ephemeral=True)


async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(MusicCommands(bot))
