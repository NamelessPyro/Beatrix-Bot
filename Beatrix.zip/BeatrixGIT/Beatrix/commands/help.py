"""
Help command for Beatrix bot.
"""
import logging
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from ..config import BotConfig


class HelpCog(commands.Cog):
    """Help and information commands."""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.config: BotConfig = bot.config
        self.logger = logging.getLogger(__name__)
    
    @app_commands.command(name="help", description="Show help information for bot commands")
    @app_commands.describe(category="Specific command category to show help for")
    @app_commands.choices(category=[
        app_commands.Choice(name="Music Playback", value="music"),
        app_commands.Choice(name="Queue Management", value="queue"),
        app_commands.Choice(name="Music Library", value="library"),
        app_commands.Choice(name="Playlists", value="playlist"),
        app_commands.Choice(name="Admin Commands", value="admin")
    ])
    async def help_command(self, interaction: discord.Interaction, category: Optional[str] = None):
        """Show help information."""
        try:
            # Defer the response to avoid timeout
            await interaction.response.defer(ephemeral=True)
            
            if category is None:
                await self._show_main_help(interaction)
            else:
                await self._show_category_help(interaction, category)
                
        except Exception as e:
            self.logger.error(f"Error in help command: {e}")
            if not interaction.response.is_done():
                embed = discord.Embed(
                    title="❌ Error",
                    description="An error occurred while displaying help.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
            else:
                embed = discord.Embed(
                    title="❌ Error",
                    description="An error occurred while displaying help.",
                    color=discord.Color.red()
                )
                await interaction.edit_original_response(embed=embed)
    
    async def _show_main_help(self, interaction: discord.Interaction):
        """Show the main help page."""
        embed = discord.Embed(
            title="🎵 Beatrix Music Bot - Help",
            description="A feature-rich Discord music bot for playing local music files and YouTube content.",
            color=discord.Color.blue()
        )
        
        # Categories
        embed.add_field(
            name="🎵 Music Playback",
            value="`/join` `/leave` `/play` `/yt` `/pause` `/resume` `/stop` `/skip` `/nowplaying` `/random`",
            inline=False
        )
        
        embed.add_field(
            name="📋 Queue Management",
            value="`/queue` `/history` `/clear` `/shuffle` `/remove` `/skipto` `/loop` `/queueinfo`",
            inline=False
        )
        
        embed.add_field(
            name="📂 Music Library",
            value="`/listsongs` `/listbyartist` `/listbyletter` `/search` `/listbyfolder` `/songinfo` `/librarystats`",
            inline=False
        )
        
        embed.add_field(
            name="💾 Playlists",
            value="`/saveplaylist` `/loadplaylist` `/listplaylists` `/deleteplaylist` `/exportplaylist`",
            inline=False
        )
        
        embed.add_field(
            name="⚙️ Admin Commands",
            value="`/botinfo` `/shutdown` `/disconnectall` (Admin/Owner only)",
            inline=False
        )
        
        embed.add_field(
            name="📝 Getting Detailed Help",
            value="Use `/help category:<category>` to get detailed information about commands in a specific category.",
            inline=False
        )
        
        embed.set_footer(text=f"Bot Version {self.config.bot_version} | Use /help category:<name> for detailed help")
        
        await interaction.edit_original_response(embed=embed)
    
    async def _show_category_help(self, interaction: discord.Interaction, category: str):
        """Show help for a specific category."""
        if category == "music":
            await self._show_music_help(interaction)
        elif category == "queue":
            await self._show_queue_help(interaction)
        elif category == "library":
            await self._show_library_help(interaction)
        elif category == "playlist":
            await self._show_playlist_help(interaction)
        elif category == "admin":
            await self._show_admin_help(interaction)
    
    async def _show_music_help(self, interaction: discord.Interaction):
        """Show music playback commands help."""
        embed = discord.Embed(
            title="🎵 Music Playback Commands",
            description="Commands for basic music playback control.",
            color=discord.Color.green()
        )
        
        commands_info = [
            ("📞 `/join`", "Join your current voice channel"),
            ("📞 `/leave`", "Leave the voice channel and clear the queue"),
            ("🎵 `/play <filename>`", "Play a song from the music library"),
            ("📺 `/yt <url_or_search>`", "Play audio from YouTube (URL or search query)"),
            ("⏸️ `/pause`", "Pause the current song"),
            ("▶️ `/resume`", "Resume playback"),
            ("⏹️ `/stop`", "Stop playback and clear the queue"),
            ("⏭️ `/skip`", "Skip to the next song"),
            ("📻 `/nowplaying`", "Show currently playing song"),
            ("🎲 `/random`", "Play a random song from the library")
        ]
        
        for name, description in commands_info:
            embed.add_field(name=name, value=description, inline=False)
        
        embed.set_footer(text="💡 Tip: Use /search to find songs in your library before playing them")
        
        await interaction.edit_original_response(embed=embed)
    
    async def _show_queue_help(self, interaction: discord.Interaction):
        """Show queue management commands help."""
        embed = discord.Embed(
            title="📋 Queue Management Commands",
            description="Commands for managing the music queue.",
            color=discord.Color.orange()
        )
        
        commands_info = [
            ("📋 `/queue`", "Show the current queue (paginated)"),
            ("📜 `/history`", "Show recently played songs"),
            ("🗑️ `/clear`", "Clear the entire queue"),
            ("🔀 `/shuffle`", "Shuffle the queue order"),
            ("❌ `/remove <position>`", "Remove a song from the queue"),
            ("⏭️ `/skipto <position>`", "Skip to a specific position in the queue"),
            ("🔁 `/loop <mode>`", "Set loop mode (off/song/queue)"),
            ("ℹ️ `/queueinfo`", "Show queue statistics and current settings")
        ]
        
        for name, description in commands_info:
            embed.add_field(name=name, value=description, inline=False)
        
        embed.set_footer(text="💡 Tip: Queue positions start from 1. Use /queueinfo to see current loop and shuffle settings")
        
        await interaction.edit_original_response(embed=embed)
    
    async def _show_library_help(self, interaction: discord.Interaction):
        """Show library browsing commands help."""
        embed = discord.Embed(
            title="📂 Music Library Commands",
            description="Commands for browsing and searching your music library.",
            color=discord.Color.purple()
        )
        
        commands_info = [
            ("📑 `/listsongs`", "List all songs in the library (paginated)"),
            ("🎤 `/listbyartist <artist>`", "List songs by a specific artist"),
            ("🔤 `/listbyletter <letter>`", "List songs starting with a specific letter"),
            ("🔍 `/search <query>`", "Search for songs by title, artist, or filename"),
            ("📁 `/listbyfolder <folder>`", "List songs in a specific folder"),
            ("📄 `/songinfo <filename>`", "Show detailed information about a song"),
            ("📊 `/librarystats`", "Show library statistics and overview")
        ]
        
        for name, description in commands_info:
            embed.add_field(name=name, value=description, inline=False)
        
        embed.set_footer(text="💡 Tip: Use /search to quickly find songs, or browse by artist/folder for organized discovery")
        
        await interaction.edit_original_response(embed=embed)
    
    async def _show_playlist_help(self, interaction: discord.Interaction):
        """Show playlist commands help."""
        embed = discord.Embed(
            title="💾 Playlist Commands",
            description="Commands for managing saved playlists.",
            color=discord.Color.blue()
        )
        
        commands_info = [
            ("💾 `/saveplaylist <name>`", "Save the current queue as a playlist"),
            ("📂 `/loadplaylist`", "Load a saved playlist into the queue"),
            ("📋 `/listplaylists`", "List all saved playlists"),
            ("🗑️ `/deleteplaylist`", "Delete a saved playlist"),
            ("📤 `/exportplaylist`", "Export a playlist to a text file")
        ]
        
        for name, description in commands_info:
            embed.add_field(name=name, value=description, inline=False)
        
        embed.add_field(
            name="📝 Playlist Loading Modes",
            value="• **Replace**: Clear current queue and load playlist\n• **Append**: Add playlist songs to current queue",
            inline=False
        )
        
        embed.set_footer(text="💡 Tip: Playlists are saved permanently and can be shared via export")
        
        await interaction.edit_original_response(embed=embed)
    
    async def _show_admin_help(self, interaction: discord.Interaction):
        """Show admin commands help."""
        embed = discord.Embed(
            title="⚙️ Admin Commands",
            description="Commands for bot administration and management.",
            color=discord.Color.red()
        )
        
        commands_info = [
            ("📊 `/botinfo`", "Display bot statistics and system information"),
            ("🔌 `/disconnectall`", "Disconnect from all voice channels (Admin only)"),
            ("🔄 `/reloadconfig`", "Reload bot configuration (Owner only)"),
            ("🗑️ `/clearlogs`", "Clear bot log files (Owner only)"),
            ("🏠 `/guilds`", "List all guilds the bot is in (Owner only)"),
            ("🛑 `/shutdown`", "Shutdown the bot gracefully (Owner only)")
        ]
        
        for name, description in commands_info:
            embed.add_field(name=name, value=description, inline=False)
        
        embed.add_field(
            name="🔐 Permission Levels",
            value="• **Public**: `/botinfo`\n• **Admin**: `/disconnectall`\n• **Owner**: All other admin commands",
            inline=False
        )
        
        embed.set_footer(text="⚠️ Admin commands require appropriate permissions")
        
        await interaction.edit_original_response(embed=embed)


async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(HelpCog(bot))
