"""
Admin commands for Beatrix bot.
"""
import logging
import psutil
import platform
from datetime import datetime, timedelta
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from ..config import BotConfig
from ..ui import ConfirmationView


class AdminCog(commands.Cog):
    """Admin commands for bot management."""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.config: BotConfig = bot.config
        self.logger = logging.getLogger(__name__)
    
    @app_commands.command(name="botinfo", description="Display bot information and statistics")
    async def botinfo(self, interaction: discord.Interaction):
        """Display bot information and statistics."""
        try:
            # Bot stats
            guild_count = len(self.bot.guilds)
            total_members = sum(guild.member_count for guild in self.bot.guilds)
            
            # Voice connections
            voice_connections = len(self.bot.voice_clients)
            active_players = sum(1 for vc in self.bot.voice_clients if vc.is_playing())
            
            # System stats
            memory = psutil.virtual_memory()
            memory_used = memory.used / 1024 / 1024 / 1024  # GB
            memory_total = memory.total / 1024 / 1024 / 1024  # GB
            memory_percent = memory.percent
            
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Bot uptime
            uptime = datetime.now() - self.bot.start_time
            uptime_str = str(uptime).split('.')[0]  # Remove microseconds
            
            embed = discord.Embed(
                title="🤖 Beatrix Bot Information",
                color=discord.Color.blue()
            )
            
            # Bot stats
            embed.add_field(
                name="📊 Bot Statistics",
                value=f"**Guilds:** {guild_count}\n"
                      f"**Total Members:** {total_members:,}\n"
                      f"**Voice Connections:** {voice_connections}\n"
                      f"**Active Players:** {active_players}",
                inline=True
            )
            
            # System stats
            embed.add_field(
                name="💻 System Statistics",
                value=f"**Memory:** {memory_used:.1f}GB / {memory_total:.1f}GB ({memory_percent:.1f}%)\n"
                      f"**CPU Usage:** {cpu_percent:.1f}%\n"
                      f"**Platform:** {platform.system()} {platform.release()}\n"
                      f"**Python:** {platform.python_version()}",
                inline=True
            )
            
            # Runtime info
            embed.add_field(
                name="⏱️ Runtime Information",
                value=f"**Uptime:** {uptime_str}\n"
                      f"**Latency:** {round(self.bot.latency * 1000)}ms\n"
                      f"**Music Library:** {len(self.bot.file_manager.get_all_files())} files",
                inline=False
            )
            
            # Version info
            embed.set_footer(
                text=f"discord.py {discord.__version__} | Bot Version {self.config.bot_version}"
            )
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            self.logger.error(f"Error in bot info command: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="An unexpected error occurred while fetching bot information.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="shutdown", description="Shutdown the bot (Owner only)")
    async def shutdown(self, interaction: discord.Interaction):
        """Shutdown the bot (Owner only)."""
        if interaction.user.id != self.config.owner_id:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="Only the bot owner can use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        embed = discord.Embed(
            title="⚠️ Confirm Shutdown",
            description="Are you sure you want to shutdown the bot?\n\n**This will disconnect all voice connections and stop the bot!**",
            color=discord.Color.orange()
        )
        
        view = ConfirmationView()
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        await view.wait()
        
        if view.confirmed:
            embed = discord.Embed(
                title="🔌 Shutting Down",
                description="Bot is shutting down gracefully...",
                color=discord.Color.red()
            )
            await interaction.edit_original_response(embed=embed, view=None)
            
            self.logger.info(f"Bot shutdown initiated by {interaction.user}")
            await self.bot.close()
        else:
            embed = discord.Embed(
                title="❌ Shutdown Cancelled",
                description="Bot shutdown was cancelled.",
                color=discord.Color.green()
            )
            await interaction.edit_original_response(embed=embed, view=None)
    
    @app_commands.command(name="clearlogs", description="Clear bot logs (Owner only)")
    async def clear_logs(self, interaction: discord.Interaction):
        """Clear bot logs (Owner only)."""
        if interaction.user.id != self.config.owner_id:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="Only the bot owner can use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Clear log files
            import os
            log_files_cleared = 0
            
            for log_file in [self.config.log_file, "beabot.log", "log.txt"]:
                if os.path.exists(log_file):
                    with open(log_file, 'w') as f:
                        f.write("")
                    log_files_cleared += 1
            
            embed = discord.Embed(
                title="🗑️ Logs Cleared",
                description=f"Successfully cleared {log_files_cleared} log files.",
                color=discord.Color.green()
            )
            
            self.logger.info(f"Logs cleared by {interaction.user}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            self.logger.error(f"Error clearing logs: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="An error occurred while clearing logs.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="reloadconfig", description="Reload bot configuration (Owner only)")
    async def reload_config(self, interaction: discord.Interaction):
        """Reload bot configuration (Owner only)."""
        if interaction.user.id != self.config.owner_id:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="Only the bot owner can use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Reload configuration
            old_prefix = self.config.command_prefix
            self.config.reload()
            
            embed = discord.Embed(
                title="🔄 Configuration Reloaded",
                description="Bot configuration has been reloaded successfully.",
                color=discord.Color.green()
            )
            
            if old_prefix != self.config.command_prefix:
                embed.add_field(
                    name="⚠️ Prefix Changed",
                    value=f"Command prefix changed from `{old_prefix}` to `{self.config.command_prefix}`",
                    inline=False
                )
            
            self.logger.info(f"Configuration reloaded by {interaction.user}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            self.logger.error(f"Error reloading config: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="An error occurred while reloading configuration.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="disconnectall", description="Disconnect from all voice channels (Admin only)")
    @app_commands.default_permissions(administrator=True)
    async def disconnect_all(self, interaction: discord.Interaction):
        """Disconnect from all voice channels (Admin only)."""
        try:
            disconnected = 0
            
            for voice_client in self.bot.voice_clients:
                try:
                    await voice_client.disconnect()
                    disconnected += 1
                except Exception as e:
                    self.logger.error(f"Error disconnecting from voice channel: {e}")
            
            embed = discord.Embed(
                title="🔌 Disconnected",
                description=f"Disconnected from {disconnected} voice channels.",
                color=discord.Color.green()
            )
            
            self.logger.info(f"Disconnected from all voice channels by {interaction.user}")
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            self.logger.error(f"Error in disconnect all command: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="An error occurred while disconnecting from voice channels.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="guilds", description="List all guilds the bot is in (Owner only)")
    async def list_guilds(self, interaction: discord.Interaction):
        """List all guilds the bot is in (Owner only)."""
        if interaction.user.id != self.config.owner_id:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="Only the bot owner can use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            guilds_info = []
            for guild in self.bot.guilds:
                voice_connected = any(vc.guild.id == guild.id for vc in self.bot.voice_clients)
                status = "🔊" if voice_connected else "💤"
                guilds_info.append(f"{status} **{guild.name}** ({guild.member_count} members)")
            
            if not guilds_info:
                description = "Bot is not in any guilds."
            else:
                description = "\n".join(guilds_info)
            
            embed = discord.Embed(
                title=f"🏠 Guild List ({len(self.bot.guilds)} total)",
                description=description,
                color=discord.Color.blue()
            )
            
            embed.set_footer(text="🔊 = Voice connected | 💤 = Not connected")
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            self.logger.error(f"Error listing guilds: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="An error occurred while listing guilds.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(AdminCog(bot))
