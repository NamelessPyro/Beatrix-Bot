# === QUEUE COMMANDS ===
"""
Queue management and viewing commands.
"""

import logging

import discord
from discord import app_commands
from discord.ext import commands

from ..enums import RepeatMode
from ..ui import PagedEmbedView, QueueControlView


class QueueCommands(commands.Cog):
    """Queue management commands."""
    
    def __init__(self, bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
    
    @app_commands.command(name="queue", description="Show the current music queue")
    async def queue(self, interaction: discord.Interaction):
        """Display the current queue."""
        guild_id = interaction.guild.id
        queue_list = self.bot.queue_manager.get_queue(guild_id)
        
        if not queue_list:
            await interaction.response.send_message("📭 The queue is empty.", ephemeral=True)
            return
        
        # Format queue entries
        entries = []
        for i, song_path in enumerate(queue_list, 1):
            relative_path = self.bot.file_manager.get_relative_path(song_path)
            entries.append(f"**{song_path.stem}**\n`{relative_path}`")
        
        # Create paginated view
        view = PagedEmbedView(
            entries=entries,
            title="🎵 Music Queue",
            color=discord.Color.purple(),
            chunk_size=5
        )
        
        embed = view.get_embed()
        
        # Add queue info
        queue_info = self.bot.queue_manager.get_queue_info(guild_id)
        embed.add_field(
            name="Queue Info",
            value=f"**Total:** {queue_info['queue_length']} songs\n"
                  f"**Size:** {queue_info['total_size_mb']} MB\n"
                  f"**Repeat:** {queue_info['repeat_mode']}",
            inline=False
        )
        
        # Add control buttons
        control_view = QueueControlView(self.bot, guild_id)
        
        # Combine views
        for item in control_view.children:
            view.add_item(item)
        
        await interaction.response.send_message(embed=embed, view=view)
    
    @app_commands.command(name="history", description="Show recently played songs")
    async def history(self, interaction: discord.Interaction):
        """Display playback history."""
        guild_id = interaction.guild.id
        history_list = self.bot.queue_manager.get_history(guild_id)
        
        if not history_list:
            await interaction.response.send_message("📭 No playback history yet.", ephemeral=True)
            return
        
        # Format history entries (reverse order for most recent first)
        entries = []
        for i, song_path in enumerate(reversed(history_list), 1):
            relative_path = self.bot.file_manager.get_relative_path(song_path)
            entries.append(f"**{song_path.stem}**\n`{relative_path}`")
        
        view = PagedEmbedView(
            entries=entries,
            title="🕐 Playback History",
            color=discord.Color.orange(),
            chunk_size=8
        )
        
        await interaction.response.send_message(embed=view.get_embed(), view=view)
    
    @app_commands.command(name="clear", description="Clear the music queue")
    async def clear(self, interaction: discord.Interaction):
        """Clear the queue."""
        guild_id = interaction.guild.id
        cleared_count = self.bot.queue_manager.clear_queue(guild_id)
        
        if cleared_count > 0:
            embed = discord.Embed(
                title="🗑️ Queue Cleared",
                description=f"Removed {cleared_count} songs from the queue.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message("📭 The queue was already empty.", ephemeral=True)
    
    @app_commands.command(name="shuffle", description="Shuffle the current queue")
    async def shuffle(self, interaction: discord.Interaction):
        """Shuffle the queue."""
        guild_id = interaction.guild.id
        
        if self.bot.queue_manager.shuffle_queue(guild_id):
            embed = discord.Embed(
                title="🔀 Queue Shuffled",
                description="The queue has been shuffled.",
                color=discord.Color.blue()
            )
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message("❌ Queue is empty or has only one song.", ephemeral=True)
    
    @app_commands.command(name="remove", description="Remove a song from the queue")
    @app_commands.describe(position="Position in queue to remove (1 = first song)")
    async def remove(self, interaction: discord.Interaction, position: int):
        """Remove a song from the queue."""
        guild_id = interaction.guild.id
        queue_list = self.bot.queue_manager.get_queue(guild_id)
        
        if not queue_list:
            await interaction.response.send_message("📭 The queue is empty.", ephemeral=True)
            return
        
        if position < 1 or position > len(queue_list):
            await interaction.response.send_message(
                f"❌ Position must be between 1 and {len(queue_list)}.",
                ephemeral=True
            )
            return
        
        # Remove song (convert to 0-based index)
        removed_song = self.bot.queue_manager.remove_from_queue(guild_id, position - 1)
        
        if removed_song:
            embed = discord.Embed(
                title="🗑️ Song Removed",
                description=f"Removed **{removed_song.stem}** from position {position}.",
                color=discord.Color.orange()
            )
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message("❌ Failed to remove song.", ephemeral=True)
    
    @app_commands.command(name="skipto", description="Skip to a specific song in the queue")
    @app_commands.describe(position="Position in queue to skip to (1 = first song)")
    async def skipto(self, interaction: discord.Interaction, position: int):
        """Skip to a specific position in the queue."""
        guild_id = interaction.guild.id
        queue_list = self.bot.queue_manager.get_queue(guild_id)
        
        if not queue_list:
            await interaction.response.send_message("📭 The queue is empty.", ephemeral=True)
            return
        
        if position < 1 or position > len(queue_list):
            await interaction.response.send_message(
                f"❌ Position must be between 1 and {len(queue_list)}.",
                ephemeral=True
            )
            return
        
        # Skip to position (convert to 0-based index)
        skipped_songs = self.bot.queue_manager.skip_to_index(guild_id, position - 1)
        
        # Stop current playback to trigger next song
        vc = interaction.guild.voice_client
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
        
        embed = discord.Embed(
            title="⏭️ Skipped to Song",
            description=f"Skipped {len(skipped_songs)} songs and jumped to position {position}.",
            color=discord.Color.blue()
        )
        
        next_song = self.bot.queue_manager.peek_next_song(guild_id)
        if next_song:
            embed.add_field(
                name="Now Playing",
                value=f"**{next_song.stem}**",
                inline=False
            )
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="loop", description="Set repeat mode for the queue")
    @app_commands.describe(mode="Repeat mode: off, one (repeat song), all (repeat queue)")
    async def loop(self, interaction: discord.Interaction, mode: str = None):
        """Set repeat mode."""
        guild_id = interaction.guild.id
        
        if mode is None:
            # Show current mode
            current_mode = self.bot.queue_manager.get_repeat_mode(guild_id)
            embed = discord.Embed(
                title="🔁 Current Repeat Mode",
                description=f"Repeat mode is currently set to: **{current_mode.value}**",
                color=discord.Color.blue()
            )
            embed.add_field(
                name="Available Modes",
                value="• `off` - No repeat\n• `one` - Repeat current song\n• `all` - Repeat entire queue",
                inline=False
            )
            await interaction.response.send_message(embed=embed)
            return
        
        try:
            repeat_mode = RepeatMode.from_string(mode)
            self.bot.queue_manager.set_repeat_mode(guild_id, repeat_mode)
            
            mode_descriptions = {
                RepeatMode.OFF: "Repeat disabled",
                RepeatMode.ONE: "Repeating current song",
                RepeatMode.ALL: "Repeating entire queue"
            }
            
            embed = discord.Embed(
                title="🔁 Repeat Mode Changed",
                description=mode_descriptions[repeat_mode],
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)
            
        except ValueError:
            await interaction.response.send_message(
                "❌ Invalid mode. Use: `off`, `one`, or `all`",
                ephemeral=True
            )
    
    @app_commands.command(name="queueinfo", description="Show detailed queue information")
    async def queueinfo(self, interaction: discord.Interaction):
        """Show detailed queue information."""
        guild_id = interaction.guild.id
        queue_info = self.bot.queue_manager.get_queue_info(guild_id)
        voice_info = self.bot.voice_manager.get_voice_channel_info(interaction.guild)
        
        embed = discord.Embed(
            title="📊 Queue Information",
            color=discord.Color.blue()
        )
        
        # Queue stats
        embed.add_field(
            name="Queue Stats",
            value=f"**Songs:** {queue_info['queue_length']}\n"
                  f"**History:** {queue_info['history_length']} songs\n"
                  f"**Size:** {queue_info['total_size_mb']} MB\n"
                  f"**Status:** {'Full' if queue_info['queue_full'] else 'Open'}",
            inline=True
        )
        
        # Playback info
        embed.add_field(
            name="Playback",
            value=f"**Current:** {queue_info['current_song'] or 'None'}\n"
                  f"**Repeat:** {queue_info['repeat_mode']}\n"
                  f"**Playing:** {'Yes' if voice_info['is_playing'] else 'No'}\n"
                  f"**Paused:** {'Yes' if voice_info['is_paused'] else 'No'}",
            inline=True
        )
        
        # Voice info
        if voice_info['connected']:
            embed.add_field(
                name="Voice Channel",
                value=f"**Channel:** {voice_info['channel_name']}\n"
                      f"**Members:** {voice_info.get('member_count', 0)}\n"
                      f"**Humans:** {voice_info.get('human_members', 0)}\n"
                      f"**Inactive:** {voice_info['inactive_time']}s",
                inline=True
            )
        else:
            embed.add_field(
                name="Voice Channel",
                value="Not connected",
                inline=True
            )
        
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(QueueCommands(bot))
