"""
Playlist management commands for Beatrix bot.
"""
import logging
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from ..config import BotConfig
from ..exceptions import PlaylistError, BotError
from ..managers import PlaylistManager, QueueManager
from ..ui import PlaylistSelectView, ConfirmationView


class PlaylistCog(commands.Cog):
    """Playlist management commands."""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.config: BotConfig = bot.config
        self.playlist_manager: PlaylistManager = bot.playlist_manager
        self.queue_manager: QueueManager = bot.queue_manager
        self.logger = logging.getLogger(__name__)
    
    @app_commands.command(name="saveplaylist", description="Save the current queue as a playlist")
    @app_commands.describe(name="Name for the new playlist")
    async def save_playlist(self, interaction: discord.Interaction, name: str):
        """Save current queue as a playlist."""
        try:
            guild_id = interaction.guild.id
            queue = self.queue_manager.get_queue(guild_id)
            
            if not queue:
                embed = discord.Embed(
                    title="❌ Cannot Save Playlist",
                    description="Queue is empty. Add some songs first!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Check if playlist already exists
            if self.playlist_manager.playlist_exists(name):
                embed = discord.Embed(
                    title="⚠️ Playlist Exists",
                    description=f"Playlist '{name}' already exists. Do you want to overwrite it?",
                    color=discord.Color.orange()
                )
                
                view = ConfirmationView()
                await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
                await view.wait()
                
                if not view.confirmed:
                    embed = discord.Embed(
                        title="❌ Save Cancelled",
                        description="Playlist save operation cancelled.",
                        color=discord.Color.red()
                    )
                    await interaction.edit_original_response(embed=embed, view=None)
                    return
            
            # Save the playlist
            saved_count = await self.playlist_manager.save_playlist(name, queue)
            
            embed = discord.Embed(
                title="✅ Playlist Saved",
                description=f"Saved **{saved_count}** songs to playlist '{name}'",
                color=discord.Color.green()
            )
            
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=embed)
            else:
                await interaction.edit_original_response(embed=embed, view=None)
                
        except PlaylistError as e:
            embed = discord.Embed(
                title="❌ Playlist Error",
                description=str(e),
                color=discord.Color.red()
            )
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=embed, ephemeral=True)
            else:
                await interaction.edit_original_response(embed=embed, view=None)
        except Exception as e:
            self.logger.error(f"Error saving playlist: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="An unexpected error occurred while saving the playlist.",
                color=discord.Color.red()
            )
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=embed, ephemeral=True)
            else:
                await interaction.edit_original_response(embed=embed, view=None)
    
    @app_commands.command(name="loadplaylist", description="Load a playlist into the queue")
    @app_commands.describe(mode="How to load the playlist (replace or append to queue)")
    @app_commands.choices(mode=[
        app_commands.Choice(name="Replace queue", value="replace"),
        app_commands.Choice(name="Append to queue", value="append")
    ])
    async def load_playlist(self, interaction: discord.Interaction, mode: str = "append"):
        """Load a playlist into the queue."""
        try:
            playlists = self.playlist_manager.list_playlists()
            
            if not playlists:
                embed = discord.Embed(
                    title="❌ No Playlists",
                    description="No playlists found. Create one with `/saveplaylist` first!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            async def on_playlist_select(selected_playlist: str, select_interaction: discord.Interaction):
                try:
                    guild_id = interaction.guild.id
                    
                    if mode == "replace":
                        self.queue_manager.clear_queue(guild_id)
                    
                    songs = await self.playlist_manager.load_playlist(selected_playlist)
                    
                    for song_path in songs:
                        self.queue_manager.add_to_queue(guild_id, song_path)
                    
                    action = "Replaced queue with" if mode == "replace" else "Added to queue"
                    embed = discord.Embed(
                        title="✅ Playlist Loaded",
                        description=f"{action} **{len(songs)}** songs from playlist '{selected_playlist}'",
                        color=discord.Color.green()
                    )
                    
                    await select_interaction.response.edit_message(embed=embed, view=None)
                    
                except PlaylistError as e:
                    embed = discord.Embed(
                        title="❌ Playlist Error",
                        description=str(e),
                        color=discord.Color.red()
                    )
                    await select_interaction.response.edit_message(embed=embed, view=None)
                except Exception as e:
                    self.logger.error(f"Error loading playlist: {e}")
                    embed = discord.Embed(
                        title="❌ Error",
                        description="An unexpected error occurred while loading the playlist.",
                        color=discord.Color.red()
                    )
                    await select_interaction.response.edit_message(embed=embed, view=None)
            
            embed = discord.Embed(
                title="📋 Select Playlist",
                description=f"Choose a playlist to {mode}:",
                color=discord.Color.blue()
            )
            
            view = PlaylistSelectView(
                playlists=playlists,
                placeholder="Choose a playlist to load...",
                callback=on_playlist_select
            )
            
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
            
        except Exception as e:
            self.logger.error(f"Error in load playlist command: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="An unexpected error occurred.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="listplaylists", description="List all saved playlists")
    async def list_playlists(self, interaction: discord.Interaction):
        """List all saved playlists."""
        try:
            playlists = self.playlist_manager.list_playlists()
            
            if not playlists:
                embed = discord.Embed(
                    title="📋 No Playlists",
                    description="No playlists found. Create one with `/saveplaylist` first!",
                    color=discord.Color.blue()
                )
                await interaction.response.send_message(embed=embed)
                return
            
            # Get playlist info
            playlist_info = []
            for playlist_name in playlists:
                try:
                    songs = await self.playlist_manager.load_playlist(playlist_name)
                    playlist_info.append(f"**{playlist_name}** - {len(songs)} songs")
                except PlaylistError:
                    playlist_info.append(f"**{playlist_name}** - Error loading")
            
            embed = discord.Embed(
                title="📋 Saved Playlists",
                description="\n".join(playlist_info),
                color=discord.Color.blue()
            )
            
            embed.set_footer(text=f"Total: {len(playlists)} playlists")
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            self.logger.error(f"Error listing playlists: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="An unexpected error occurred while listing playlists.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="deleteplaylist", description="Delete a saved playlist")
    async def delete_playlist(self, interaction: discord.Interaction):
        """Delete a saved playlist."""
        try:
            playlists = self.playlist_manager.list_playlists()
            
            if not playlists:
                embed = discord.Embed(
                    title="❌ No Playlists",
                    description="No playlists found to delete.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            async def on_playlist_select(selected_playlist: str, select_interaction: discord.Interaction):
                try:
                    # Confirmation dialog
                    embed = discord.Embed(
                        title="⚠️ Confirm Deletion",
                        description=f"Are you sure you want to delete playlist '{selected_playlist}'?\n\n**This action cannot be undone!**",
                        color=discord.Color.orange()
                    )
                    
                    view = ConfirmationView()
                    await select_interaction.response.edit_message(embed=embed, view=view)
                    await view.wait()
                    
                    if view.confirmed:
                        self.playlist_manager.delete_playlist(selected_playlist)
                        
                        embed = discord.Embed(
                            title="✅ Playlist Deleted",
                            description=f"Successfully deleted playlist '{selected_playlist}'",
                            color=discord.Color.green()
                        )
                    else:
                        embed = discord.Embed(
                            title="❌ Deletion Cancelled",
                            description="Playlist deletion was cancelled.",
                            color=discord.Color.red()
                        )
                    
                    await select_interaction.edit_original_response(embed=embed, view=None)
                    
                except PlaylistError as e:
                    embed = discord.Embed(
                        title="❌ Playlist Error",
                        description=str(e),
                        color=discord.Color.red()
                    )
                    await select_interaction.edit_original_response(embed=embed, view=None)
                except Exception as e:
                    self.logger.error(f"Error deleting playlist: {e}")
                    embed = discord.Embed(
                        title="❌ Error",
                        description="An unexpected error occurred while deleting the playlist.",
                        color=discord.Color.red()
                    )
                    await select_interaction.edit_original_response(embed=embed, view=None)
            
            embed = discord.Embed(
                title="🗑️ Delete Playlist",
                description="Choose a playlist to delete:",
                color=discord.Color.red()
            )
            
            view = PlaylistSelectView(
                playlists=playlists,
                placeholder="Choose a playlist to delete...",
                callback=on_playlist_select
            )
            
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
            
        except Exception as e:
            self.logger.error(f"Error in delete playlist command: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="An unexpected error occurred.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="exportplaylist", description="Export a playlist to a text file")
    async def export_playlist(self, interaction: discord.Interaction):
        """Export a playlist to a text file."""
        try:
            playlists = self.playlist_manager.list_playlists()
            
            if not playlists:
                embed = discord.Embed(
                    title="❌ No Playlists",
                    description="No playlists found to export.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            async def on_playlist_select(selected_playlist: str, select_interaction: discord.Interaction):
                try:
                    export_path = await self.playlist_manager.export_playlist(selected_playlist)
                    
                    embed = discord.Embed(
                        title="✅ Playlist Exported",
                        description=f"Playlist '{selected_playlist}' exported to:\n`{export_path}`",
                        color=discord.Color.green()
                    )
                    
                    # Try to send the file as an attachment
                    try:
                        file = discord.File(export_path)
                        await select_interaction.response.edit_message(
                            embed=embed, 
                            view=None,
                            attachments=[file]
                        )
                    except Exception:
                        # If file is too large or other error, just send the path
                        await select_interaction.response.edit_message(embed=embed, view=None)
                    
                except PlaylistError as e:
                    embed = discord.Embed(
                        title="❌ Playlist Error",
                        description=str(e),
                        color=discord.Color.red()
                    )
                    await select_interaction.response.edit_message(embed=embed, view=None)
                except Exception as e:
                    self.logger.error(f"Error exporting playlist: {e}")
                    embed = discord.Embed(
                        title="❌ Error",
                        description="An unexpected error occurred while exporting the playlist.",
                        color=discord.Color.red()
                    )
                    await select_interaction.response.edit_message(embed=embed, view=None)
            
            embed = discord.Embed(
                title="📤 Export Playlist",
                description="Choose a playlist to export:",
                color=discord.Color.blue()
            )
            
            view = PlaylistSelectView(
                playlists=playlists,
                placeholder="Choose a playlist to export...",
                callback=on_playlist_select
            )
            
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
            
        except Exception as e:
            self.logger.error(f"Error in export playlist command: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="An unexpected error occurred.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(PlaylistCog(bot))
