# === LIBRARY COMMANDS ===
"""
Music library browsing and searching commands.
"""

import logging

import discord
from discord import app_commands
from discord.ext import commands

from ..ui import PagedEmbedView


class LibraryCommands(commands.Cog):
    """Music library browsing commands."""
    
    def __init__(self, bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
    
    @app_commands.command(name="listsongs", description="List all available songs")
    async def listsongs(self, interaction: discord.Interaction):
        """List all songs in the music library."""
        files = self.bot.file_manager.find_audio_files()
        
        if not files:
            await interaction.response.send_message("📭 No songs found in the music library.", ephemeral=True)
            return
        
        # Format entries
        entries = []
        for file_path in files:
            relative_path = self.bot.file_manager.get_relative_path(file_path)
            entries.append(f"**{file_path.stem}**\n`{relative_path}`")
        
        view = PagedEmbedView(
            entries=entries,
            title=f"🎵 All Songs ({len(files)} total)",
            color=discord.Color.blue(),
            chunk_size=5
        )
        
        await interaction.response.send_message(embed=view.get_embed(), view=view)
    
    @app_commands.command(name="listbyartist", description="List songs grouped by artist")
    async def listbyartist(self, interaction: discord.Interaction):
        """List songs grouped by artist."""
        artists_dict = self.bot.file_manager.get_files_by_artist()
        
        if not artists_dict:
            await interaction.response.send_message("📭 No songs found in the music library.", ephemeral=True)
            return
        
        # Format entries
        entries = []
        for artist, songs in sorted(artists_dict.items()):
            entries.append(f"**🎤 {artist}** ({len(songs)} songs)")
            for song in sorted(songs, key=lambda x: x.stem):
                entries.append(f"  • {song.stem}")
        
        view = PagedEmbedView(
            entries=entries,
            title=f"🎤 Songs by Artist ({len(artists_dict)} artists)",
            color=discord.Color.green(),
            chunk_size=10
        )
        
        await interaction.response.send_message(embed=view.get_embed(), view=view)
    
    @app_commands.command(name="listbyletter", description="List songs starting with a specific letter")
    @app_commands.describe(letter="The first letter of the song title (A-Z)")
    async def listbyletter(self, interaction: discord.Interaction, letter: str):
        """List songs starting with a specific letter."""
        if not letter or len(letter) != 1 or not letter.isalpha():
            await interaction.response.send_message("❌ Please provide a single letter (A-Z).", ephemeral=True)
            return
        
        files = self.bot.file_manager.get_files_by_letter(letter)
        
        if not files:
            await interaction.response.send_message(
                f"📭 No songs found starting with '{letter.upper()}'.",
                ephemeral=True
            )
            return
        
        # Format entries
        entries = []
        for file_path in sorted(files, key=lambda x: x.stem.lower()):
            relative_path = self.bot.file_manager.get_relative_path(file_path)
            entries.append(f"**{file_path.stem}**\n`{relative_path}`")
        
        view = PagedEmbedView(
            entries=entries,
            title=f"🔤 Songs starting with '{letter.upper()}' ({len(files)} songs)",
            color=discord.Color.orange(),
            chunk_size=8
        )
        
        await interaction.response.send_message(embed=view.get_embed(), view=view)
    
    @app_commands.command(name="search", description="Search for songs by name")
    @app_commands.describe(query="Search term to look for in song titles")
    async def search(self, interaction: discord.Interaction, query: str):
        """Search for songs by name."""
        if len(query) < 2:
            await interaction.response.send_message("❌ Search query must be at least 2 characters.", ephemeral=True)
            return
        
        # Search for multiple matches
        matches = self.bot.file_manager.search_multiple(query, limit=50)
        
        if not matches:
            await interaction.response.send_message(f"📭 No songs found matching '{query}'.", ephemeral=True)
            return
        
        # Format entries
        entries = []
        for file_path in matches:
            relative_path = self.bot.file_manager.get_relative_path(file_path)
            entries.append(f"**{file_path.stem}**\n`{relative_path}`")
        
        view = PagedEmbedView(
            entries=entries,
            title=f"🔍 Search results for '{query}' ({len(matches)} songs)",
            color=discord.Color.purple(),
            chunk_size=8
        )
        
        await interaction.response.send_message(embed=view.get_embed(), view=view)
    
    @app_commands.command(name="listbyfolder", description="List songs in a specific folder")
    @app_commands.describe(folder="Folder name within your music directory")
    async def listbyfolder(self, interaction: discord.Interaction, folder: str):
        """List songs in a specific folder."""
        # Security check - prevent directory traversal
        if ".." in folder or folder.startswith("/") or "\\" in folder:
            await interaction.response.send_message("❌ Invalid folder name.", ephemeral=True)
            return
        
        try:
            files = self.bot.file_manager.get_files_in_folder(folder)
            
            if not files:
                await interaction.response.send_message(f"📭 No songs found in folder '{folder}'.", ephemeral=True)
                return
            
            # Format entries
            entries = []
            for file_path in sorted(files, key=lambda x: x.stem.lower()):
                file_info = self.bot.file_manager.get_file_info(file_path)
                entries.append(f"**{file_path.stem}**\n`{file_info['size']}`")
            
            view = PagedEmbedView(
                entries=entries,
                title=f"📁 Songs in '{folder}' ({len(files)} songs)",
                color=discord.Color.gold(),
                chunk_size=10
            )
            
            await interaction.response.send_message(embed=view.get_embed(), view=view)
            
        except Exception as e:
            self.logger.error(f"Error listing folder '{folder}': {e}")
            await interaction.response.send_message(f"❌ Folder '{folder}' not found or inaccessible.", ephemeral=True)
    
    @app_commands.command(name="songinfo", description="Get detailed information about a song")
    @app_commands.describe(query="Song name or search term")
    async def songinfo(self, interaction: discord.Interaction, query: str):
        """Get detailed information about a song."""
        song_path = self.bot.file_manager.search_by_keyword(query)
        
        if not song_path:
            await interaction.response.send_message(f"📭 No song found matching '{query}'.", ephemeral=True)
            return
        
        file_info = self.bot.file_manager.get_file_info(song_path)
        
        embed = discord.Embed(
            title="🎵 Song Information",
            description=f"**{file_info['name']}**",
            color=discord.Color.blue()
        )
        
        embed.add_field(name="Artist/Album", value=file_info['artist'], inline=True)
        embed.add_field(name="Format", value=file_info['extension'].upper(), inline=True)
        embed.add_field(name="Size", value=file_info['size'], inline=True)
        embed.add_field(name="Path", value=f"`{file_info['relative_path']}`", inline=False)
        
        # Check if song exists
        if song_path.exists():
            embed.add_field(name="Status", value="✅ Available", inline=True)
        else:
            embed.add_field(name="Status", value="❌ File not found", inline=True)
        
        embed.set_footer(text=f"Use '/play {query}' to add to queue")
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="librarystats", description="Show music library statistics")
    async def librarystats(self, interaction: discord.Interaction):
        """Show music library statistics."""
        files = self.bot.file_manager.find_audio_files()
        artists_dict = self.bot.file_manager.get_files_by_artist()
        
        if not files:
            await interaction.response.send_message("📭 No songs found in the music library.", ephemeral=True)
            return
        
        # Calculate statistics
        total_size = sum(f.stat().st_size for f in files if f.exists())
        total_size_gb = total_size / (1024 ** 3)
        
        # Count by format
        formats = {}
        for file_path in files:
            ext = file_path.suffix.lower()
            formats[ext] = formats.get(ext, 0) + 1
        
        embed = discord.Embed(
            title="📊 Music Library Statistics",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="General",
            value=f"**Total Songs:** {len(files):,}\n"
                  f"**Total Artists:** {len(artists_dict):,}\n"
                  f"**Total Size:** {total_size_gb:.2f} GB",
            inline=True
        )
        
        # Format breakdown
        format_text = "\n".join([f"**{ext.upper()}:** {count:,}" for ext, count in sorted(formats.items())])
        embed.add_field(
            name="Formats",
            value=format_text or "None",
            inline=True
        )
        
        # Top artists
        top_artists = sorted(artists_dict.items(), key=lambda x: len(x[1]), reverse=True)[:5]
        if top_artists:
            artist_text = "\n".join([f"**{artist}:** {len(songs)}" for artist, songs in top_artists])
            embed.add_field(
                name="Top Artists",
                value=artist_text,
                inline=True
            )
        
        embed.set_footer(text=f"Library path: {self.bot.config.music_dir}")
        
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(LibraryCommands(bot))
