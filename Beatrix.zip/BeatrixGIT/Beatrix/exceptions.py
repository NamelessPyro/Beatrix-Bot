# === CUSTOM EXCEPTIONS ===
"""
Custom exceptions for BeaBot.
"""


class BotError(Exception):
    """Base exception for bot errors."""
    pass


class QueueFullError(BotError):
    """Raised when queue is full."""
    def __init__(self, max_length: int):
        self.max_length = max_length
        super().__init__(f"Queue is full (max {max_length})")


class NoSongsFoundError(BotError):
    """Raised when no songs are found."""
    pass


class VoiceConnectionError(BotError):
    """Raised when voice connection fails."""
    pass


class PlaybackError(BotError):
    """Raised when playback fails."""
    pass


class YouTubeDownloadError(BotError):
    """Raised when YouTube download fails."""
    pass


class PlaylistError(BotError):
    """Raised when playlist operations fail."""
    pass
