# === MUSIC PLAYER ===
"""
Handles music playback with auto-reconnection and error handling.
"""

import asyncio
import logging
from pathlib import Path
from typing import Optional

import discord

from .config import BotConfig
from .managers import QueueManager, VoiceConnectionManager
from .exceptions import PlaybackError


class MusicPlayer:
    """Handles music playback."""
    
    def __init__(self, config: BotConfig, queue_manager: QueueManager, voice_manager: VoiceConnectionManager):
        self.config = config
        self.queue_manager = queue_manager
        self.voice_manager = voice_manager
        self.logger = logging.getLogger(__name__)
        self._play_locks = {}  # guild_id: asyncio.Lock
    
    async def play_next(self, guild: discord.Guild, text_channel: Optional[discord.TextChannel] = None) -> bool:
        """Play next song in queue. Returns True if playback started."""
        guild_id = guild.id
        if guild_id not in self._play_locks:
            self._play_locks[guild_id] = asyncio.Lock()
        lock = self._play_locks[guild_id]
        async with lock:
            vc = guild.voice_client
            self.logger.debug(f"[play_next] Called for guild {guild.name}, vc={vc}")
            if not vc:
                self.logger.warning(f"No voice client for guild {guild.name}")
                return False
            next_song = self.queue_manager.get_next_song(guild_id)
            if not next_song:
                self.logger.info(f"Queue empty for {guild.name}")
                if text_channel:
                    await text_channel.send("🔇 Queue finished!")
                return False
            # Add to history
            self.queue_manager.add_to_history(guild_id, next_song)
            loop = asyncio.get_event_loop()
            def after_playing(error):
                self.logger.debug(f"[after_playing] Called for guild {guild.name}, error={error}")
                if error:
                    self.logger.error(f"Playback error: {error}")
                    if text_channel:
                        asyncio.run_coroutine_threadsafe(text_channel.send(f"❌ Playback error: {error}"), loop)
                self.voice_manager.update_activity(guild_id)
                # Schedule next song without blocking
                asyncio.run_coroutine_threadsafe(self.play_next(guild, text_channel), loop)
            try:
                # Create audio source
                source = self._create_audio_source(next_song)
                self.logger.debug(f"[play_next] Created audio source for {next_song}")
                # Start playback
                vc.play(source, after=after_playing)
                self.voice_manager.update_activity(guild_id)
                # Send now playing message
                if text_channel:
                    embed = self._create_now_playing_embed(next_song)
                    await text_channel.send(embed=embed)
                self.logger.info(f"Playing {next_song.name} in {guild.name}")
                return True
            except Exception as e:
                self.logger.error(f"Failed to play {next_song}: {e}")
                if text_channel:
                    await text_channel.send(f"❌ Failed to play: **{next_song.name}**")
                # Try next song if this one failed
                return await self.play_next(guild, text_channel)
    
    def _create_audio_source(self, file_path: Path) -> discord.AudioSource:
        """Create appropriate audio source for the file."""
        file_str = str(file_path)
        
        # Check if it's a URL or local file
        if file_str.startswith(('http://', 'https://')):
            # Online source with reconnection options
            before_options = "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5"
            return discord.FFmpegPCMAudio(
                file_str,
                executable=str(self.config.ffmpeg_path),
                before_options=before_options
            )
        else:
            # Local file
            return discord.FFmpegPCMAudio(
                file_str,
                executable=str(self.config.ffmpeg_path)
            )
    
    def _create_now_playing_embed(self, file_path: Path) -> discord.Embed:
        """Create embed for now playing message."""
        embed = discord.Embed(
            title="🎵 Now Playing",
            description=f"**{file_path.stem}**",
            color=discord.Color.green()
        )
        
        # Add file info if available
        if file_path.exists():
            file_size = file_path.stat().st_size / 1024 / 1024  # MB
            embed.add_field(
                name="File Info",
                value=f"Size: {file_size:.1f} MB\nFormat: {file_path.suffix.upper()}",
                inline=True
            )
        
        # Add artist info (from directory name)
        embed.add_field(
            name="Artist/Album",
            value=file_path.parent.name,
            inline=True
        )
        
        embed.set_footer(text="Use /queue to see upcoming songs")
        return embed
    
    async def stop_playback(self, guild: discord.Guild, clear_queue: bool = True) -> bool:
        """Stop current playback and optionally clear queue."""
        vc = guild.voice_client
        if not vc:
            return False
        
        try:
            if vc.is_playing() or vc.is_paused():
                vc.stop()
            
            if clear_queue:
                self.queue_manager.clear_queue(guild.id)
            
            self.logger.info(f"Stopped playback for {guild.name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error stopping playback for {guild.name}: {e}")
            return False
    
    async def pause_playback(self, guild: discord.Guild) -> bool:
        """Pause current playback."""
        vc = guild.voice_client
        if vc and vc.is_playing():
            vc.pause()
            self.logger.info(f"Paused playback for {guild.name}")
            return True
        return False
    
    async def resume_playback(self, guild: discord.Guild) -> bool:
        """Resume paused playback."""
        vc = guild.voice_client
        if vc and vc.is_paused():
            vc.resume()
            self.voice_manager.update_activity(guild.id)
            self.logger.info(f"Resumed playback for {guild.name}")
            return True
        return False
    
    async def skip_current_song(self, guild: discord.Guild) -> bool:
        """Skip the currently playing song."""
        vc = guild.voice_client
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()  # This will trigger the after_playing callback
            self.logger.info(f"Skipped song for {guild.name}")
            return True
        return False
    
    def get_playback_info(self, guild: discord.Guild) -> dict:
        """Get current playback information."""
        vc = guild.voice_client
        queue_info = self.queue_manager.get_queue_info(guild.id)
        
        return {
            "is_connected": vc is not None,
            "is_playing": vc.is_playing() if vc else False,
            "is_paused": vc.is_paused() if vc else False,
            "current_song": queue_info["current_song"],
            "queue_length": queue_info["queue_length"],
            "repeat_mode": queue_info["repeat_mode"],
            "voice_channel": vc.channel.name if vc and vc.channel else None
        }
