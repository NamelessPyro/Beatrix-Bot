# 🎵 Beatrix Discord Music Bot

A feature-rich Discord music bot built with modern Python architecture. Beatrix supports local music files, YouTube downloads, queue management, playlists, and much more.

## ✨ Features

### 🎵 Music Playback
- **Local Music Library**: Play MP3, FLAC, WAV, M4A, and OGG files from your music directory
- **YouTube Integration**: Download and play audio from YouTube videos and playlists
- **High-Quality Audio**: Configurable audio quality and format options
- **Auto-Reconnection**: Automatically reconnects to voice channels if disconnected

### 📋 Queue Management
- **Advanced Queue System**: Add, remove, shuffle, and reorder songs
- **Loop Modes**: Loop single songs, entire queue, or disable looping
- **Queue History**: Track recently played songs
- **Smart Auto-Disconnect**: Automatically leaves voice channels after inactivity

### 💾 Playlist System
- **Save & Load Playlists**: Create and manage persistent playlists
- **Export Playlists**: Export playlists to text files for sharing
- **Flexible Loading**: Replace queue or append to existing queue

### 📂 Library Management
- **Smart Search**: Search by title, artist, or filename
- **Browse by Artist**: Organized music browsing by artist/folder
- **Detailed Info**: Get detailed information about songs and library stats
- **Large Library Support**: Optimized for handling thousands of songs

### 🎛️ Discord UI
- **Slash Commands**: Modern Discord slash command interface
- **Interactive Embeds**: Beautiful, paginated displays for queues and lists
- **Button Controls**: Interactive buttons for queue management
- **Real-time Updates**: Live status updates and now-playing information

### ⚙️ Admin Features
- **Bot Statistics**: Monitor bot performance and usage
- **Configuration Management**: Runtime configuration updates
- **Graceful Shutdown**: Proper cleanup and disconnect procedures
- **Logging System**: Comprehensive logging with configurable levels

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- FFmpeg (included in this repository)
- Discord Bot Token

### Installation

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd BeaBot
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up environment variables**
   ```bash
   # Windows (PowerShell)
   $env:DISCORD_TOKEN="your_discord_bot_token_here"
   
   # Linux/Mac
   export DISCORD_TOKEN="your_discord_bot_token_here"
   ```

4. **Configure music directory** (optional)
   ```bash
   # Default is D:/Music on Windows
   $env:MUSIC_DIR="C:/Path/To/Your/Music"
   ```

5. **Run the bot**
   ```bash
   python main.py
   ```

## 🎵 Basic Usage

### Essential Commands

| Command | Description |
|---------|-------------|
| `/join` | Join your voice channel |
| `/play <song>` | Play a song from your library |
| `/yt <query>` | Download and play from YouTube |
| `/queue` | View the current queue |
| `/skip` | Skip to the next song |
| `/help` | Show all available commands |

### Example Usage
```
/join                           # Join voice channel
/play never gonna give you up   # Play from local library
/yt https://youtube.com/...     # Play from YouTube
/queue                          # View current queue
/shuffle                        # Shuffle the queue
/saveplaylist favorites         # Save current queue as playlist
```

## 📁 Project Structure

```
BeaBot/
├── Beatrix/                    # Main bot package
│   ├── bot.py                  # Main bot class
│   ├── config.py               # Configuration management
│   ├── exceptions.py           # Custom exceptions
│   ├── enums.py               # Enumerations
│   ├── music_player.py        # Music playback logic
│   ├── managers/              # Core managers
│   │   ├── file_manager.py    # Music file operations
│   │   ├── queue_manager.py   # Queue management
│   │   ├── voice_manager.py   # Voice connections
│   │   ├── youtube_manager.py # YouTube downloading
│   │   └── playlist_manager.py # Playlist operations
│   ├── ui/                    # Discord UI components
│   │   └── components.py      # Interactive components
│   └── commands/              # Command cogs
│       ├── music.py           # Music playback commands
│       ├── queue.py           # Queue management commands
│       ├── library.py         # Library browsing commands
│       ├── playlist.py        # Playlist commands
│       ├── admin.py           # Admin commands
│       └── help.py            # Help system
├── ffmpeg/                    # FFmpeg binaries
├── main.py                    # Entry point
├── requirements.txt           # Python dependencies
└── README.md                  # This file
```

## ⚙️ Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DISCORD_TOKEN` | *Required* | Your Discord bot token |
| `MUSIC_DIR` | `D:/Music` | Path to your music library |
| `FFMPEG_PATH` | `d:/BeaBot/ffmpeg/bin/ffmpeg.exe` | Path to FFmpeg executable |
| `MAX_QUEUE_LENGTH` | `100` | Maximum songs in queue |
| `AUTO_DISCONNECT_TIMEOUT` | `300` | Auto-disconnect timeout (seconds) |
| `LOG_LEVEL` | `INFO` | Logging level (DEBUG, INFO, WARNING, ERROR) |

### Music Directory Structure
```
Music/
├── Artist 1/
│   ├── song1.mp3
│   └── song2.flac
├── Artist 2/
│   └── album/
│       ├── track1.mp3
│       └── track2.mp3
└── VenturingSalinder/          # YouTube downloads
    └── downloaded_video.mp3
```

## 🎛️ Command Reference

### Music Playback
- `/join` - Join your voice channel
- `/leave` - Leave voice channel and clear queue
- `/play <filename>` - Play a song from your library
- `/yt <url_or_search>` - Play from YouTube
- `/pause` - Pause playback
- `/resume` - Resume playback
- `/stop` - Stop and clear queue
- `/skip` - Skip current song
- `/nowplaying` - Show current song info
- `/random` - Play random song

### Queue Management
- `/queue` - View current queue
- `/history` - View recently played songs
- `/clear` - Clear the queue
- `/shuffle` - Shuffle queue order
- `/remove <position>` - Remove song from queue
- `/skipto <position>` - Skip to specific queue position
- `/loop <mode>` - Set loop mode (off/song/queue)
- `/queueinfo` - Show queue statistics

### Library Browsing
- `/listsongs` - List all songs (paginated)
- `/listbyartist <artist>` - List songs by artist
- `/listbyletter <letter>` - List songs starting with letter
- `/search <query>` - Search for songs
- `/listbyfolder <folder>` - List songs in folder
- `/songinfo <filename>` - Show song details
- `/librarystats` - Show library statistics

### Playlists
- `/saveplaylist <name>` - Save current queue as playlist
- `/loadplaylist` - Load a saved playlist
- `/listplaylists` - List all playlists
- `/deleteplaylist` - Delete a playlist
- `/exportplaylist` - Export playlist to file

### Admin Commands
- `/botinfo` - Show bot statistics
- `/disconnectall` - Disconnect from all channels (Admin)
- `/shutdown` - Shutdown bot (Owner only)
- `/reloadconfig` - Reload configuration (Owner only)
- `/clearlogs` - Clear log files (Owner only)
- `/guilds` - List bot guilds (Owner only)

## 🛠️ Development

### Architecture

Beatrix follows a modular architecture with clear separation of concerns:

- **Managers**: Handle specific functionality (files, queues, voice, etc.)
- **Commands**: Organized into cogs by functionality
- **UI Components**: Reusable Discord interface elements
- **Configuration**: Centralized configuration management
- **Error Handling**: Comprehensive error handling and logging

### Adding New Features

1. **New Commands**: Add to appropriate cog in `commands/`
2. **New Managers**: Create in `managers/` and register in `__init__.py`
3. **UI Components**: Add to `ui/components.py`
4. **Configuration**: Update `config.py` for new settings

### Testing

```bash
# Install development dependencies
pip install pytest pytest-asyncio

# Run tests (when implemented)
pytest tests/
```

## 🐛 Troubleshooting

### Common Issues

1. **Bot not responding to commands**
   - Check Discord token is correct
   - Ensure bot has proper permissions in the server
   - Verify slash commands are synced (`/help` should show if working)

2. **Music not playing**
   - Check FFmpeg path is correct
   - Ensure music directory exists and contains supported files
   - Verify bot has voice channel permissions

3. **YouTube downloads failing**
   - Check internet connection
   - YouTube-dl/yt-dlp may need updating
   - Some videos may be region-locked or unavailable

4. **Performance issues**
   - Large music libraries may take time to scan initially
   - Consider adjusting `MAX_QUEUE_LENGTH` for memory usage
   - Check system resources with `/botinfo`

### Logging

Enable debug logging for troubleshooting:
```bash
$env:LOG_LEVEL="DEBUG"
```

Logs are saved to `logs/beatrix.log` by default.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 🙏 Acknowledgments

- [discord.py](https://github.com/Rapptz/discord.py) - Discord API wrapper
- [yt-dlp](https://github.com/yt-dlp/yt-dlp) - YouTube downloading
- [FFmpeg](https://ffmpeg.org/) - Audio processing

---

Made with ❤️ for the Discord music community
