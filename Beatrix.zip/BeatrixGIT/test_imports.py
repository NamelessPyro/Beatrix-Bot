#!/usr/bin/env python3
"""
Test script to verify Beatrix bot imports and basic functionality.
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

def test_imports():
    """Test that all modules can be imported successfully."""
    print("🔍 Testing imports...")
    
    try:
        from Beatrix.config import BotConfig
        print("✅ Config module imported")
        
        from Beatrix.exceptions import BotError, QueueFullError
        print("✅ Exceptions module imported")
        
        from Beatrix.enums import RepeatMode, AudioFormat
        print("✅ Enums module imported")
        
        from Beatrix.managers import (
            MusicFileManager, QueueManager, VoiceConnectionManager,
            YouTubeDownloader, PlaylistManager
        )
        print("✅ Managers imported")
        
        from Beatrix.music_player import MusicPlayer
        print("✅ Music player imported")
        
        from Beatrix.ui import (
            PagedEmbedView, PlaylistSelectView, ConfirmationView,
            QueueControlView
        )
        print("✅ UI components imported")
        
        print("🎉 All imports successful!")
        return True
        
    except Exception as e:
        print(f"❌ Import error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_config():
    """Test configuration creation."""
    print("\n🔧 Testing configuration...")
    
    try:
        from Beatrix.config import BotConfig
        config = BotConfig()
        
        print(f"✅ Music directory: {config.music_dir}")
        print(f"✅ FFmpeg path: {config.ffmpeg_path}")
        print(f"✅ Bot version: {config.bot_version}")
        print(f"✅ Max queue length: {config.max_queue_length}")
        
        return True
        
    except Exception as e:
        print(f"❌ Config error: {e}")
        return False

def test_file_manager():
    """Test file manager basic functionality."""
    print("\n📁 Testing file manager...")
    
    try:
        from Beatrix.config import BotConfig
        from Beatrix.managers import MusicFileManager
        
        config = BotConfig()
        file_manager = MusicFileManager(config)
        
        # Test file discovery (don't actually scan, just test method exists)
        print("✅ File manager created")
        print("✅ File discovery methods available")
        
        return True
        
    except Exception as e:
        print(f"❌ File manager error: {e}")
        return False

def main():
    """Run all tests."""
    print("🎵 Beatrix Bot - Import Test\n")
    
    tests = [
        test_imports,
        test_config,
        test_file_manager
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print(f"\n📊 Test Results: {passed}/{total} passed")
    
    if passed == total:
        print("🎉 All tests passed! Bot should work correctly.")
        return 0
    else:
        print("❌ Some tests failed. Check the errors above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
